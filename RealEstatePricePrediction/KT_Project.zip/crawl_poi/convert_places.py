"""
convert_places.py
-----------------
Convert raw JSON place files → cleaned CSV files.

Expected input structure:
    places/
        colleges_raw.json
        high_schools_raw.json
        hospitals_raw.json
        kindergartens_raw.json
        malls_raw.json
        markets_raw.json
        middle_schools_raw.json
        mrt_stations_raw.json
        parks_raw.json
        primary_schools_raw.json
        roads_raw.json
        supermarkets_raw.json
        universities_raw.json

Output (written next to this script, or pass --output-dir):
    retail_places.csv
    schools.csv
    mrt_stations.csv
    roads.csv
    hospitals.csv
    parks.csv

Usage:
    python convert_places.py --input-dir places --output-dir output
"""

import json
import csv
import math
import re
import argparse
from pathlib import Path


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def load_json(path: Path):
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    # support both bare list and {"features": [...]} / {"data": [...]}
    if isinstance(data, list):
        return data
    for key in ("features", "data", "records", "items"):
        if key in data and isinstance(data[key], list):
            return data[key]
    raise ValueError(f"Cannot find record list in {path}")


def parse_point(geojson_str):
    """Extract (lon, lat) from a GeoJSON Point string. Returns (None, None) on failure."""
    if not geojson_str:
        return None, None
    try:
        if isinstance(geojson_str, str):
            obj = json.loads(geojson_str)
        else:
            obj = geojson_str
        coords = obj.get("coordinates", [])
        return coords[0], coords[1]
    except Exception:
        return None, None


def centroid(geojson_str):
    """
    Compute a simple centroid from a LineString or MultiLineString GeoJSON string.
    Returns (lon, lat, geometry_type) or (None, None, None).
    """
    if not geojson_str:
        return None, None, None
    try:
        if isinstance(geojson_str, str):
            obj = json.loads(geojson_str)
        else:
            obj = geojson_str
        gtype = obj.get("type")
        coords = obj.get("coordinates", [])

        points = []
        if gtype == "LineString":
            points = coords
        elif gtype == "MultiLineString":
            for segment in coords:
                points.extend(segment)
        else:
            return None, None, gtype

        if not points:
            return None, None, gtype

        lon = sum(p[0] for p in points) / len(points)
        lat = sum(p[1] for p in points) / len(points)
        return round(lon, 8), round(lat, 8), gtype
    except Exception:
        return None, None, None


def extract_line_number(tuyen_str):
    """Extract numeric line number from 'Tuyến số 1: Bến Thành - Suối Tiên' → 1"""
    if not tuyen_str:
        return None
    m = re.search(r"số\s*(\d+)", tuyen_str, re.IGNORECASE)
    return int(m.group(1)) if m else None


LAYER_TO_PLACE_TYPE = {
    "ICTHCM_HCM_CHO": "cho",
    "ICTHCM_HCM_SIEUTHI": "sieu_thi",
    "ICTHCM_HCM_TRUNGTAMTHUONGMAI": "trung_tam_thuong_mai",
}

LAYER_TO_SCHOOL_LEVEL = {
    "ICTHCM_EDU_MAMNON": "mam_non",
    "ICTHCM_EDU_TIEUHOC": "tieu_hoc",
    "ICTHCM_EDU_THCS": "thcs",
    "ICTHCM_EDU_THPT": "thpt",
    "ICTHCM_EDU_CAODANG": "cao_dang",
    "ICTHCM_EDU_DAIHOC": "dai_hoc",
}


def write_csv(path: Path, fieldnames: list, rows: list):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    print(f"  ✓ {path.name:30s}  {len(rows):>6,} records")


# ---------------------------------------------------------------------------
# 1. retail_places.csv  (chợ + siêu thị + mall)
# ---------------------------------------------------------------------------

RETAIL_FILES = {
    "markets_raw.json":     "cho",
    "supermarkets_raw.json":"sieu_thi",
    "malls_raw.json":       "trung_tam_thuong_mai",
}

RETAIL_FIELDS = ["id", "name", "longitude", "latitude", "place_type", "address", "district"]


def convert_retail(input_dir: Path, output_dir: Path):
    rows = []
    for filename, place_type in RETAIL_FILES.items():
        records = load_json(input_dir / filename)
        for r in records:
            lon, lat = parse_point(r.get("vitritrenbando"))
            rows.append({
                "id":         r.get("Id"),
                "name":       r.get("donvi") or r.get("Title"),
                "longitude":  lon,
                "latitude":   lat,
                "place_type": place_type,
                "address":    r.get("diachi"),
                "district":   r.get("thanhphoquanhuyen"),
            })
    write_csv(output_dir / "retail_places.csv", RETAIL_FIELDS, rows)


# ---------------------------------------------------------------------------
# 2. schools.csv  (mầm non → đại học)
# ---------------------------------------------------------------------------

SCHOOL_FILES = [
    "kindergartens_raw.json",
    "primary_schools_raw.json",
    "middle_schools_raw.json",
    "high_schools_raw.json",
    "colleges_raw.json",
    "universities_raw.json",
]

SCHOOL_FIELDS = ["id", "name", "longitude", "latitude", "school_level", "address", "district", "ward"]


def convert_schools(input_dir: Path, output_dir: Path):
    rows = []
    for filename in SCHOOL_FILES:
        records = load_json(input_dir / filename)
        for r in records:
            layer = r.get("Layer", "")
            school_level = LAYER_TO_SCHOOL_LEVEL.get(layer, layer)

            # tọa độ: ưu tiên RLongitude/RLatitude, fallback parse vitri
            lon = r.get("RLongitude")
            lat = r.get("RLatitude")
            if lon is None or lat is None:
                lon, lat = parse_point(r.get("vitri"))

            rows.append({
                "id":           r.get("Id"),
                "name":         r.get("tendonvi") or r.get("Title"),
                "longitude":    lon,
                "latitude":     lat,
                "school_level": school_level,
                "address":      r.get("diachi"),
                "district":     r.get("quanhuyen"),
                "ward":         r.get("phuongxa"),
            })
    write_csv(output_dir / "schools.csv", SCHOOL_FIELDS, rows)


# ---------------------------------------------------------------------------
# 3. mrt_stations.csv
# ---------------------------------------------------------------------------

MRT_FIELDS = ["id", "name", "longitude", "latitude", "line_name", "line_number"]


def convert_mrt(input_dir: Path, output_dir: Path):
    records = load_json(input_dir / "mrt_stations_raw.json")
    rows = []
    for r in records:
        lon, lat = parse_point(r.get("vitritrenbando"))
        tuyen = r.get("thuoctuyen")
        rows.append({
            "id":          r.get("Id"),
            "name":        r.get("tendiadiem") or r.get("Title"),
            "longitude":   lon,
            "latitude":    lat,
            "line_name":   tuyen,
            "line_number": extract_line_number(tuyen),
        })
    write_csv(output_dir / "mrt_stations.csv", MRT_FIELDS, rows)


# ---------------------------------------------------------------------------
# 4. roads.csv
# ---------------------------------------------------------------------------

ROAD_FIELDS = [
    "id", "name",
    "geometry_type", "geometry",
    "centroid_lon", "centroid_lat",
    "road_type", "surface",
    "district", "managing_unit",
    "start_point", "end_point",
    "length_m", "width_m", "area_sqm",
    "year_built", "notes",
]


def convert_roads(input_dir: Path, output_dir: Path):
    records = load_json(input_dir / "roads_raw.json")
    rows = []
    for r in records:
        shape_raw = r.get("Shape")
        clon, clat, gtype = centroid(shape_raw)

        # store geometry as compact JSON string (or keep original string)
        geom_str = None
        if shape_raw:
            try:
                # re-serialize as compact JSON to normalise whitespace
                geom_str = json.dumps(json.loads(shape_raw), ensure_ascii=False, separators=(",", ":"))
            except Exception:
                geom_str = shape_raw

        rows.append({
            "id":            r.get("Id"),
            "name":          r.get("TenDuong") or r.get("Title"),
            "geometry_type": gtype,
            "geometry":      geom_str,
            "centroid_lon":  clon,
            "centroid_lat":  clat,
            "road_type":     r.get("TenLoaiDuong"),
            "surface":       r.get("TenKetCauMatDuong"),
            "district":      r.get("TenQuan"),
            "managing_unit": r.get("TenDonViQuanLy"),
            "start_point":   r.get("DiemDau"),
            "end_point":     r.get("DiemCuoi"),
            "length_m":      r.get("ChieuDaiMatDuong"),
            "width_m":       r.get("BeRongMCNMatDuong"),
            "area_sqm":      r.get("DienTichMatDuong"),
            "year_built":    r.get("NamXayDung"),
            "notes":         r.get("GhiChu"),
        })
    write_csv(output_dir / "roads.csv", ROAD_FIELDS, rows)


# ---------------------------------------------------------------------------
# 5. hospitals.csv
# ---------------------------------------------------------------------------

HOSPITAL_FIELDS = ["id", "name", "longitude", "latitude", "address"]


def convert_hospitals(input_dir: Path, output_dir: Path):
    records = load_json(input_dir / "hospitals_raw.json")
    rows = []
    for r in records:
        lon, lat = parse_point(r.get("vitri"))
        rows.append({
            "id":        r.get("Id"),
            "name":      r.get("tenbenhvien") or r.get("Title"),
            "longitude": lon,
            "latitude":  lat,
            "address":   r.get("diachi"),
        })
    write_csv(output_dir / "hospitals.csv", HOSPITAL_FIELDS, rows)


# ---------------------------------------------------------------------------
# 6. parks.csv
# ---------------------------------------------------------------------------

PARK_FIELDS = ["id", "name", "longitude", "latitude", "address", "district", "ward"]


def convert_parks(input_dir: Path, output_dir: Path):
    records = load_json(input_dir / "parks_raw.json")
    rows = []
    for r in records:
        lon, lat = parse_point(r.get("vitritrenbando"))
        rows.append({
            "id":       r.get("Id"),
            "name":     r.get("donvi") or r.get("Title"),
            "longitude": lon,
            "latitude":  lat,
            "address":  r.get("diachi"),
            "district": r.get("thanhphoquanhuyen"),
            "ward":     r.get("phuongxa"),
        })
    write_csv(output_dir / "parks.csv", PARK_FIELDS, rows)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Convert place JSON files to CSV")
    parser.add_argument("--input-dir",  default="places",  help="Folder containing raw JSON files")
    parser.add_argument("--output-dir", default="poi",  help="Folder to write CSV files")
    args = parser.parse_args()

    input_dir  = Path(args.input_dir)
    output_dir = Path(args.output_dir)

    print(f"\nInput : {input_dir.resolve()}")
    print(f"Output: {output_dir.resolve()}\n")

    converters = [
        ("retail_places.csv",  convert_retail),
        ("schools.csv",        convert_schools),
        ("mrt_stations.csv",   convert_mrt),
        ("roads.csv",          convert_roads),
        ("hospitals.csv",      convert_hospitals),
        ("parks.csv",          convert_parks),
    ]

    for label, fn in converters:
        try:
            fn(input_dir, output_dir)
        except FileNotFoundError as e:
            print(f"  ✗ {label}: file not found — {e}")
        except Exception as e:
            print(f"  ✗ {label}: ERROR — {e}")

    print("\nDone.")


if __name__ == "__main__":
    main()