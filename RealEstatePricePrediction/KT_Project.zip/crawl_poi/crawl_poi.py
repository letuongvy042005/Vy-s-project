import requests
import json
import time
import os

# Tao thu muc places neu chua co
os.makedirs("places", exist_ok=True)

TOKEN = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1bmlxdWVfbmFtZSI6InB1YmxpY19sYXllcl9kYXRhIiwidXNlcm5hbWUiOiJwdWJsaWNfbGF5ZXJfZGF0YSIsInBJZHMiOiI2MDQ4IiwiaWQiOiIyNDkiLCJuYW1lIjoicHVibGljX2xheWVyX2RhdGEiLCJwaWN0dXJlIjoiaHR0cHM6Ly9oZ2lzMi52aWV0YmFuZG8udm4vYXBpL3YyL3VzZXJzL3VzZXJpbmZvL3BpY3R1cmUvcHVibGljX2xheWVyX2RhdGFAdmJkLnZuL3AiLCJlbWFpbCI6InB1YmxpY19sYXllcl9kYXRhQHZiZC52biIsImlhdCI6IjE3NzY2NTA2ODkiLCJpc3MiOiJ2ZG1zIiwiZXhwIjoxODYzMDUwNjg5LCJuYmYiOjE3NzY2NTA2ODl9.8Pf5t_UsWDi1QhAot1Lf_nYXsHe75C-jJLtfldd-Ndk"

COOKIE_STRING = "_ga=GA1.3.366296056.1777035896; _gid=GA1.3.1545903232.1777035896; _pk_id.5.ffea=a16a054c92f210fe.1777035900.; vdmsPublicAccesstoken=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1bmlxdWVfbmFtZSI6InB1YmxpY19sYXllcl9kYXRhIiwidXNlcm5hbWUiOiJwdWJsaWNfbGF5ZXJfZGF0YSIsInBJZHMiOiI2MDQ4IiwiaWQiOiIyNDkiLCJuYW1lIjoicHVibGljX2xheWVyX2RhdGEiLCJwaWN0dXJlIjoiaHR0cHM6Ly9oZ2lzMi52aWV0YmFuZG8udm4vYXBpL3YyL3VzZXJzL3VzZXJpbmZvL3BpY3R1cmUvcHVibGljX2xheWVyX2RhdGFAdmJkLnZuL3AiLCJlbWFpbCI6InB1YmxpY19sYXllcl9kYXRhQHZiZC52biIsImlhdCI6IjE3NzY2NTA2ODkiLCJpc3MiOiJ2ZG1zIiwiZXhwIjoxODYzMDUwNjg5LCJuYmYiOjE3NzY2NTA2ODl9.8Pf5t_UsWDi1QhAot1Lf_nYXsHe75C-jJLtfldd-Ndk; _pk_ref.5.ffea=%5B%22%22%2C%22%22%2C1777083669%2C%22https%3A%2F%2Fwww.google.com%2F%22%5D; _pk_ses.5.ffea=1; TS01c4b7aa=0150c7cfd138142d6c18954a6f354556353340a8b7c4e4c18665a1a61c1ffeb5ec4bd5ad99a6ddcf68981fb7f546638615770c55d62072f2713354bfba8e4211bc888d02af; TS0146297d=0150c7cfd1d5450925342e67e2e13a9ac79cd61f8127bc0895f3728043102b82ee6e81738f007c389999668b142e1bf8ea26b3b693c3643638483f48ed1bbe2558e1d472ec; _frontend=1833370322.20480.0000; TS013f4524=0150c7cfd1362682bda7a601f2be30831afc6ad97dea8e16e3e4b1eb3e0ad914cdc75fcc924419219e4cd107dd5cb5c12c28557f966fb7c5c5e467b629a86aa82692492c9c6361277f3c962cdb09d0ef6d5ad8776e"

headers = {
    'accept': '*/*',
    'authorization': f'bearer {TOKEN}',
    'content-type': 'application/json',
    'cookie': COOKIE_STRING,
    'origin': 'https://bando.tphcm.gov.vn',
    'referer': 'https://bando.tphcm.gov.vn/',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
}

# Danh sach cac layer can lay
layers = [
    # {"name": "ICTHCM_HCM_SIEUTHI", "file": "places/supermarkets_raw.json", "title": "Sieu thi"},
    # {"name": "ICTHCM_BENHVIEN", "file": "places/hospitals_raw.json", "title": "Benh vien"},
    # {"name": "ICTHCM_NHA_GA_TRAM_DUNG_MRT", "file": "places/mrt_stations_raw.json", "title": "Ga MRT"},
    # {"name": "ICTHCM_HCM_CHO", "file": "places/markets_raw.json", "title": "Cho"},
    # {"name": "ICTHCM_HCM_TRUNGTAMTHUONGMAI", "file": "places/malls_raw.json", "title": "Trung tam thuong mai"},
    # {"name": "ICTHCM_EDU_CAODANG", "file": "places/colleges_raw.json", "title": "Cao dang"},
    # {"name": "ICTHCM_EDU_DAIHOC", "file": "places/universities_raw.json", "title": "Dai hoc"},
    # {"name": "ICTHCM_EDU_MAMNON", "file": "places/kindergartens_raw.json", "title": "Mam non"},
    # {"name": "ICTHCM_EDU_TIEUHOC", "file": "places/primary_schools_raw.json", "title": "Tieu hoc"},
    # {"name": "ICTHCM_EDU_THCS", "file": "places/middle_schools_raw.json", "title": "THCS"},
    # {"name": "ICTHCM_EDU_THPT", "file": "places/high_schools_raw.json", "title": "THPT"},
    # {"name": "ICTHCM_HCM_CONGVIEN", "file": "places/parks_raw.json", "title": "Cong vien"},
    # {"name": "ICTHCM_TIM_DUONG", "file": "places/roads_raw.json", "title": "Duong"},
    {"name": "ICTHCM_THANH_PHO_HO_CHI_MINH_3T", "file": "places/wards_boundary.json", "title": "Ranh giơi phuong"},
]


def fetch_raw_data(layer_name, output_file, title):
    all_data = []
    page = 1
    total = None
    url = f"https://bando.tphcm.gov.vn/api/vdms-data/{layer_name}/query"

    print(f"\nDang lay {title}...")

    while True:
        body = {
            "page": page,
            "limit": 100,
            "filters": [],
            "sort": []
        }

        print(f"  Trang {page}...", end=" ")

        try:
            response = requests.post(url, headers=headers, json=body, timeout=30)

            if response.status_code != 200:
                print(f"Loi {response.status_code}")
                break

            data = response.json()
            items = data.get('data', [])

            if total is None:
                total = data.get('total', 0)
                print(f"tong {total} ban ghi")
            else:
                print()

            if not items:
                print("  -> het du lieu")
                break

            all_data.extend(items)
            print(f"     da lay {len(all_data)}/{total}")

            if len(all_data) >= total:
                print("  -> da lay het")
                break

            page += 1
            time.sleep(0.3)

        except Exception as e:
            print(f"Loi: {e}")
            break

    # Luu nguyen response vao file
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(all_data, f, ensure_ascii=False, indent=2)

    print(f"  Da luu {len(all_data)} ban ghi vao {output_file}")


# Chay lay tung layer
for layer in layers:
    fetch_raw_data(layer["name"], layer["file"], layer["title"])

print("\nHoan tat! Tat ca du lieu da duoc luu vao thu muc places/")