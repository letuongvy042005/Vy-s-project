import random
import time
import re
import pandas as pd
import os
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup

# CẤU HÌNH
DATA_DIR = r"D:\HPKT\batdongsan\data"
URL_DIR = r"D:\HPKT\batdongsan\url"
MAX_PAGES = None

chrome_options = Options()
chrome_options.add_experimental_option("debuggerAddress", "127.0.0.1:9222")
driver = webdriver.Chrome(options=chrome_options)
print("Connected to Chrome")

BASE_URL = "https://batdongsan.com.vn/du-an-bat-dong-san-tp-hcm"
QUERY_PARAMS = "?sts=2,1"


# HÀM TIỆN ÍCH
def safe_text(el):
    return el.text.strip() if el else None


def get_number(text):
    if not text:
        return None
    text = str(text).replace(".", "").replace(",", ".")
    match = re.search(r"(\d+(?:\.\d+)?)", text)
    if match:
        return float(match.group(1))
    return None


def parse_land_area(text):
    if not text:
        return None
    text = text.lower().strip()
    num = get_number(text)
    if num:
        if "ha" in text:
            return num
        elif "m²" in text or "m2" in text:
            return num / 10000
    return num


def generate_project_id():
    return f"DA_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{random.randint(100, 999)}"


# LẤY DANH SÁCH DỰ ÁN
def get_projects_from_page():
    projects = []
    cards = driver.find_elements(By.CSS_SELECTOR, ".re__prj-card-full")
    print(f"   Found {len(cards)} project cards")

    for card in cards:
        try:
            link_elem = card.find_element(By.CSS_SELECTOR, "a")
            url = link_elem.get_attribute("href")
            if not url or "batdongsan.com.vn" not in url:
                continue

            projects.append({
                "url": url,
                "title": safe_text(card.find_element(By.CSS_SELECTOR, ".re__prj-card-title")),
                "status": safe_text(card.find_element(By.CSS_SELECTOR, ".re__prj-tag-info label")),
                "location_raw": safe_text(card.find_element(By.CSS_SELECTOR, ".re__prj-card-location"))
            })
        except Exception:
            continue
    return projects


def crawl_all_pages():
    all_projects = []
    seen_urls = set()
    page = 1

    while True:
        url = f"{BASE_URL}{QUERY_PARAMS}" if page == 1 else f"{BASE_URL}/p{page}{QUERY_PARAMS}"
        print(f"\nPage {page}: {url}")

        driver.get(url)
        time.sleep(random.uniform(3, 5))
        driver.execute_script("window.scrollBy(0, 500);")
        time.sleep(1)

        projects = get_projects_from_page()
        new_projects = [p for p in projects if p["url"] not in seen_urls]

        for p in new_projects:
            seen_urls.add(p["url"])
            all_projects.append(p)

        print(f"   Found: {len(projects)} projects, New: {len(new_projects)}, Total: {len(all_projects)}")

        if len(new_projects) == 0:
            print("   No new projects found. Stopping.")
            break

        if MAX_PAGES and page >= MAX_PAGES:
            print(f"   Reached max pages limit ({MAX_PAGES}). Stopping.")
            break

        page += 1

    return all_projects


# CRAWL CHI TIẾT DỰ ÁN
def crawl_project_detail(project_info):
    url = project_info["url"]

    try:
        print(f"   Accessing: {url}")
        driver.get(url)
        WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".project-main-info"))
        )
        time.sleep(2)
        soup = BeautifulSoup(driver.page_source, "html.parser")

        # === THÔNG TIN CƠ BẢN ===
        project_name = safe_text(soup.select_one(".re__project-name")) or project_info["title"]
        address_raw = safe_text(soup.select_one(".re__project-address")) or project_info["location_raw"]
        description = safe_text(soup.select_one(".js__prj-detail-content"))
        project_type = safe_text(soup.select_one(".re__prj-cat span"))
        project_status = safe_text(soup.select_one(".re__prj-tag-info label")) or project_info["status"]
        brand = safe_text(soup.select_one(".re__prj-investor a"))

        # === TỌA ĐỘ ===
        longitude = latitude = None
        map_div = soup.select_one("#data-album-google-map")
        if map_div:
            src = map_div.get("data-src", "")
            match = re.search(r'q=([-\d.]+),([-\d.]+)', src)
            if match:
                latitude = float(match.group(1))
                longitude = float(match.group(2))

        # === 3 THÔNG SỐ ĐẦU TRANG ===
        land_area_ha = None
        total_apartment = None

        wrappers = soup.select(".re__project-info-details .re__project-info-details__wrapper")

        for wrapper in wrappers:
            icon_elem = wrapper.select_one(".re__project-info-details__icon")
            if not icon_elem:
                continue

            icon_class = " ".join(icon_elem.get("class", []))

            if "money" in icon_class:
                continue

            value = safe_text(wrapper.select_one(".re__project-info-details__value"))
            unit = safe_text(wrapper.select_one(".re__project-info-details__unit"))

            if "house" in icon_class:
                total_apartment = get_number(value)
            elif "building" in icon_class:
                land_area_ha = parse_land_area(f"{value} {unit}" if unit else value)

        # === THÔNG TIN CHI TIẾT (.re__project-box-item) ===
        num_towers = None
        construction_density = None
        launch_year = None
        handover_year = None
        ownership = None

        for item in soup.select(".re__project-box-item"):
            label = safe_text(item.select_one("label"))
            value = safe_text(item.select_one("span"))

            if not label or not value:
                continue

            label_lower = label.lower()

            if "diện tích" in label_lower and not land_area_ha:
                land_area_ha = parse_land_area(value)
            elif "số căn hộ" in label_lower and not total_apartment:
                total_apartment = get_number(value)
            elif "số tòa" in label_lower or "quy mô" in label_lower:
                num_towers = get_number(value)
            elif "mật độ" in label_lower:
                construction_density = get_number(value)
            elif "khởi công" in label_lower:
                launch_year = get_number(value)
            elif "bàn giao" in label_lower or "hoàn thành" in label_lower:
                handover_year = get_number(value)
            elif "pháp lý" in label_lower or "sở hữu" in label_lower:
                ownership = value

        # === TIỆN ÍCH ===
        amenities = [safe_text(li).lower() for li in soup.select(".re__prj-facilities ul li") if safe_text(li)]

        has_mall = 1 if any('trung tâm thương mại' in a or 'siêu thị' in a for a in amenities) else 0
        has_school = 1 if any('trường' in a for a in amenities) else 0
        has_hospital = 1 if any('bệnh viện' in a or 'trạm y tế' in a for a in amenities) else 0
        has_park = 1 if any('công viên' in a for a in amenities) else 0
        has_pool = 1 if any('hồ bơi' in a for a in amenities) else 0
        has_parkinglot = 1 if any('bãi đỗ' in a or 'bãi giữ' in a for a in amenities) else 0

        # === KẾT QUẢ ===
        return {
            "project_id": generate_project_id(),
            "project_name": project_name,
            "project_type": project_type,
            "project_status": project_status,
            "brand": brand,
            "address_raw": address_raw,
            "longitude": longitude,
            "latitude": latitude,
            "city": None,
            "district": None,
            "ward": None,
            "street": None,
            "land_area_ha": land_area_ha,
            "num_towers": num_towers,
            "total_apartment": total_apartment,
            "construction_density": construction_density,
            "dist_cbd_km": None,
            "dist_metro_km": None,
            "dist_river_lake_km": None,
            "dist_highway_km": None,
            "dist_airport_km": None,
            "dist_market": None,
            "dist_school": None,
            "dist_park": None,
            "dist_hospital": None,
            "has_mall": has_mall,
            "has_school": has_school,
            "has_hospital": has_hospital,
            "has_park": has_park,
            "has_pool": has_pool,
            "has_parkinglot": has_parkinglot,
            "launch_year": launch_year,
            "handover_year": handover_year,
            "ownership": ownership,
            "description": description,
            "source_url": url,
            "crawled_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "note": None
        }

    except Exception as e:
        print(f"   Error: {str(e)[:100]}")
        return None


# MAIN
def main():
    print("\n" + "=" * 60)
    print("START CRAWLING PROJECTS")
    print("=" * 60)
    print(f"Configuration: MAX_PAGES = {MAX_PAGES if MAX_PAGES else 'Unlimited'}")

    # Bước 1: Lấy danh sách URL
    all_projects = crawl_all_pages()

    if not all_projects:
        print("No projects found!")
        driver.quit()
        return

    # Lưu danh sách URL
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    url_file = os.path.join(URL_DIR, f"urls_{timestamp}.csv")
    pd.DataFrame(all_projects).to_csv(url_file, index=False, encoding="utf-8-sig")
    print(f"\nSaved {len(all_projects)} URLs to: {url_file}")

    # Bước 2: Crawl chi tiết
    print("\n[STEP 2] Crawling project details...")
    print("-" * 40)

    project_data = []
    failed_urls = []

    for i, project_info in enumerate(all_projects, 1):
        print(f"\n[{i}/{len(all_projects)}] {project_info['title']}")
        data = crawl_project_detail(project_info)

        if data:
            project_data.append(data)
            land_info = f"{data['land_area_ha']:.4f} ha" if data['land_area_ha'] else "N/A"
            apt_info = str(int(data['total_apartment'])) if data['total_apartment'] else "N/A"
            print(f"Land: {land_info} | Apartments: {apt_info}")
        else:
            failed_urls.append(project_info['url'])
            print(f"Failed")

        time.sleep(random.uniform(1.5, 3))

    # Bước 3: Lưu kết quả
    if project_data:
        df = pd.DataFrame(project_data)

        columns = ["project_id", "project_name", "project_type", "project_status", "brand",
                   "address_raw", "longitude", "latitude", "city", "district", "ward", "street",
                   "land_area_ha", "num_towers", "total_apartment", "construction_density",
                   "dist_cbd_km", "dist_metro_km", "dist_river_lake_km", "dist_highway_km",
                   "dist_airport_km", "dist_market", "dist_school", "dist_park", "dist_hospital",
                   "has_mall", "has_school", "has_hospital", "has_park", "has_pool", "has_parkinglot",
                   "launch_year", "handover_year", "ownership", "description",
                   "source_url", "crawled_date", "note"]

        df = df[[c for c in columns if c in df.columns]]
        data_file = os.path.join(DATA_DIR, f"projects_hcm_{timestamp}.csv")
        df.to_csv(data_file, index=False, encoding="utf-8-sig")

        if failed_urls:
            fail_file = os.path.join(URL_DIR, f"failed_urls_{timestamp}.csv")
            pd.DataFrame({"url": failed_urls}).to_csv(fail_file, index=False, encoding="utf-8-sig")
    else:
        print("No data collected!")

    driver.quit()
    print("\nDone!")


if __name__ == "__main__":
    main()