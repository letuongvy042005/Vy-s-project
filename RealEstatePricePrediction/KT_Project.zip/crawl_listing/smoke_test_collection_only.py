from __future__ import annotations

import importlib
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent

REQUIRED_FILES = [
    'batdongsan_crawler_v1.py',
    'collect_batdongsan.py',
    'collect_homedy.py',
    'collect_nhadatcanban.py',
    'run_collectors.py',
    'common_utils.py',
    'multisource_helpers.py',
    'config.collection.example.yaml',
    'requirements_collection_only.txt',
]

MODULES = [
    'common_utils',
    'multisource_helpers',
    'batdongsan_crawler_v1',
    'collect_batdongsan',
    'collect_homedy',
    'collect_nhadatcanban',
    'run_collectors',
]


def main() -> None:
    missing = [f for f in REQUIRED_FILES if not (ROOT / f).exists()]
    if missing:
        raise SystemExit(f'Thiếu file: {missing}')

    for mod in MODULES:
        importlib.import_module(mod)

    with open(ROOT / 'config.collection.example.yaml', 'r', encoding='utf-8') as f:
        cfg = yaml.safe_load(f) or {}

    assert 'project' in cfg and 'snapshot_date' in cfg['project']
    assert 'sources' in cfg
    assert 'paths' in cfg and 'crawl_output_root' in cfg['paths']

    # Kiểm tra load_url_list hoạt động đúng
    from multisource_helpers import load_url_list
    urls = load_url_list(base_url_file=None, base_urls_str="https://a.com,https://b.com,https://a.com")
    assert urls == ["https://a.com", "https://b.com"], f"load_url_list dedup thất bại: {urls}"

    print('SMOKE TEST COLLECTION-ONLY PASSED')


if __name__ == '__main__':
    main()
