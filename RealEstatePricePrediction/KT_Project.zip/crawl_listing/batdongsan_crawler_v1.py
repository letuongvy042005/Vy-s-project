import argparse
import logging
import random
import re
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from urllib.parse import urljoin

import pandas as pd
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.common.exceptions import TimeoutException, WebDriverException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


SOURCE_NAME = "batdongsan"
DETAIL_ROOT_SELECTOR = "#product-detail-web"
LIST_CARD_SELECTOR = "#product-lists-web .re__card-full"
LIST_LINK_SELECTOR = "a.js__product-link-for-product-id"


@dataclass
class CrawlConfig:
    base_url: str
    project: str
    city: str
    brand: str
    output_dir: Path
    max_pages: int
    wait_timeout: int
    min_delay: float
    max_delay: float
    detail_min_delay: float
    detail_max_delay: float
    snapshot_date: str
    remote_debug_address: Optional[str]
    headless: bool
    resume: bool
    save_every: int


def setup_logging(output_dir: Path, snapshot_date: str) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    log_path = output_dir / f"crawl_{snapshot_date}.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(log_path, encoding="utf-8"),
        ],
    )


def slugify(text: str) -> str:
    text = text.strip().lower()
    text = re.sub(r"[^a-z0-9\u00C0-\u024f\u1E00-\u1EFF]+", "-", text)
    text = re.sub(r"-+", "-", text).strip("-")
    return text or "unknown"


def safe_text(el) -> Optional[str]:
    return el.get_text(" ", strip=True) if el else None


def normalize_whitespace(text: Optional[str]) -> Optional[str]:
    if text is None:
        return None
    return re.sub(r"\s+", " ", text).strip() or None


def parse_float_vi(text: Optional[str]) -> Optional[float]:
    if not text:
        return None
    s = text.lower().strip()
    s = s.replace("m²", "m2")
    # Keep only first reasonable numeric token
    match = re.search(r"\d+[\.,]?\d*", s)
    if not match:
        return None
    token = match.group(0)

    # Vietnamese pages often use comma as decimal separator for units like 3,2 tỷ
    # but dot as thousands separator is uncommon in these fields.
    if "," in token and "." in token:
        token = token.replace(".", "").replace(",", ".")
    elif "," in token:
        token = token.replace(",", ".")
    return float(token)


def parse_price_to_vnd(text: Optional[str]) -> Optional[int]:
    if not text:
        return None

    s = normalize_whitespace(text.lower())
    if not s or "thỏa thuận" in s or "lien he" in s or "liên hệ" in s:
        return None

    # Handle ranges like 3,2 - 3,5 tỷ => take lower bound for deterministic behavior
    first_part = re.split(r"-|–|—|~|đến", s)[0].strip()
    num = parse_float_vi(first_part)
    if num is None:
        return None

    if "tỷ" in first_part:
        return int(num * 1_000_000_000)
    if "triệu" in first_part:
        return int(num * 1_000_000)
    if "nghìn" in first_part:
        return int(num * 1_000)
    if "đ" in first_part or "vnđ" in first_part or "vnd" in first_part:
        return int(num)

    return None


def parse_area_m2(text: Optional[str]) -> Optional[float]:
    if not text:
        return None
    s = normalize_whitespace(text.lower())
    # Handle patterns like 5 x 20 m
    dim = re.search(r"(\d+[\.,]?\d*)\s*[x×]\s*(\d+[\.,]?\d*)", s)
    if dim:
        a = parse_float_vi(dim.group(1))
        b = parse_float_vi(dim.group(2))
        if a and b:
            return round(a * b, 2)
    return parse_float_vi(s)


def parse_int_value(text: Optional[str]) -> Optional[int]:
    value = parse_float_vi(text)
    if value is None:
        return None
    return int(round(value))


def build_driver(config: CrawlConfig) -> webdriver.Chrome:
    chrome_options = Options()
    if config.remote_debug_address:
        chrome_options.add_experimental_option("debuggerAddress", config.remote_debug_address)
        logging.info("Kết nối Chrome đang mở tại %s", config.remote_debug_address)
    else:
        if config.headless:
            chrome_options.add_argument("--headless=new")
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--window-size=1600,1200")
        logging.info("Khởi tạo Chrome mới | headless=%s", config.headless)

    driver = webdriver.Chrome(options=chrome_options)
    driver.set_page_load_timeout(config.wait_timeout + 15)
    return driver


class BatdongsanCrawlerV1:
    def __init__(self, config: CrawlConfig):
        self.config = config
        self.driver = build_driver(config)
        self.wait = WebDriverWait(self.driver, config.wait_timeout)

        prefix = f"{SOURCE_NAME}_{slugify(config.project)}_{slugify(config.city)}_{config.snapshot_date}"
        self.urls_raw_path = config.output_dir / f"{prefix}_urls_raw.csv"
        self.details_raw_path = config.output_dir / f"{prefix}_details_raw.csv"
        self.details_clean_path = config.output_dir / f"{prefix}_details_clean.csv"
        self.errors_path = config.output_dir / f"{prefix}_errors.csv"

    def close(self) -> None:
        try:
            self.driver.quit()
        except Exception:
            pass

    def random_sleep(self, min_delay: float, max_delay: float) -> None:
        time.sleep(random.uniform(min_delay, max_delay))

    def load_existing_urls(self) -> Tuple[List[Dict], set]:
        if self.config.resume and self.urls_raw_path.exists():
            df = pd.read_csv(self.urls_raw_path)
            rows = df.to_dict("records")
            seen = set(df["listing_url"].dropna().astype(str).tolist())
            logging.info("Resume URL raw: đã có %s URL", len(seen))
            return rows, seen
        return [], set()

    def load_existing_details(self) -> Tuple[List[Dict], set]:
        if self.config.resume and self.details_raw_path.exists():
            df = pd.read_csv(self.details_raw_path)
            rows = df.to_dict("records")
            seen = set(df["listing_url"].dropna().astype(str).tolist())
            logging.info("Resume details raw: đã có %s URL chi tiết", len(seen))
            return rows, seen
        return [], set()

    def save_dataframe(self, rows: List[Dict], path: Path) -> None:
        df = pd.DataFrame(rows)
        df.to_csv(path, index=False, encoding="utf-8-sig")

    def append_error(self, row: Dict) -> None:
        df = pd.DataFrame([row])
        header = not self.errors_path.exists()
        df.to_csv(self.errors_path, mode="a", header=header, index=False, encoding="utf-8-sig")

    def build_page_url(self, page: int) -> str:
        return self.config.base_url if page == 1 else f"{self.config.base_url}/p{page}"

    def get_listings_from_current_page(self, page_url: str, page_number: int) -> List[Dict]:
        cards = self.driver.find_elements(By.CSS_SELECTOR, LIST_CARD_SELECTOR)
        logging.info("Trang %s có %s card", page_number, len(cards))

        rows: List[Dict] = []
        for idx, card in enumerate(cards, start=1):
            try:
                card_class = (card.get_attribute("class") or "").lower()
                if "promoted" in card_class:
                    continue
                if card.find_elements(By.CSS_SELECTOR, ".re__native-sponsored-ad"):
                    continue
                if card.find_elements(By.CSS_SELECTOR, "img[src*='expired']"):
                    continue

                link = card.find_element(By.CSS_SELECTOR, LIST_LINK_SELECTOR)
                url = link.get_attribute("href")
                if not url:
                    continue
                if "batdongsan.com.vn" not in url:
                    continue
                url = urljoin("https://batdongsan.com.vn", url)

                row = {
                    "source_name": SOURCE_NAME,
                    "snapshot_date": self.config.snapshot_date,
                    "project": self.config.project,
                    "city": self.config.city,
                    "brand": self.config.brand,
                    "page_number": page_number,
                    "card_index": idx,
                    "list_page_url": page_url,
                    "listing_type_raw": card.get_attribute("vtp"),
                    "listing_url": url,
                }
                rows.append(row)
            except Exception as exc:
                logging.warning("Lỗi parse card tại trang %s vị trí %s: %s", page_number, idx, exc)
        return rows

    def crawl_list_pages(self) -> List[Dict]:
        all_rows, seen_urls = self.load_existing_urls()
        stagnant_pages = 0

        for page_number in range(1, self.config.max_pages + 1):
            page_url = self.build_page_url(page_number)
            logging.info("Đang crawl list page %s | %s", page_number, page_url)
            try:
                self.driver.get(page_url)
                self.random_sleep(self.config.min_delay, self.config.max_delay)
                self.wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, LIST_CARD_SELECTOR)))
            except TimeoutException:
                logging.warning("Timeout ở page %s", page_url)
                stagnant_pages += 1
                if stagnant_pages >= 2:
                    break
                continue
            except Exception as exc:
                logging.error("Lỗi load page %s: %s", page_url, exc)
                stagnant_pages += 1
                if stagnant_pages >= 2:
                    break
                continue

            page_rows = self.get_listings_from_current_page(page_url, page_number)
            new_rows = [r for r in page_rows if r["listing_url"] not in seen_urls]
            for row in new_rows:
                seen_urls.add(row["listing_url"])
            all_rows.extend(new_rows)

            logging.info("Page %s | mới=%s | tổng unique=%s", page_number, len(new_rows), len(seen_urls))

            self.save_dataframe(all_rows, self.urls_raw_path)

            if not new_rows:
                stagnant_pages += 1
            else:
                stagnant_pages = 0

            if stagnant_pages >= 2:
                logging.info("Hai trang liên tiếp không có URL mới -> dừng list crawl")
                break

        logging.info("Hoàn tất list crawl | tổng URL unique=%s", len(seen_urls))
        return all_rows

    def parse_detail_page(self, url: str, listing_type_raw: Optional[str]) -> Optional[Dict]:
        self.driver.get(url)
        self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, DETAIL_ROOT_SELECTOR)))
        self.random_sleep(self.config.detail_min_delay, self.config.detail_max_delay)

        soup = BeautifulSoup(self.driver.page_source, "html.parser")

        titles = soup.select("h1.re__pr-title")
        listing_title = None
        for title_el in titles:
            text = safe_text(title_el)
            if text and "mã tin" not in text.lower():
                listing_title = text
                break

        description = safe_text(
            soup.select_one("#product-detail-web .re__pr-description .re__section-body")
        )

        posted_date = None
        expired_date = None
        short_info_rows = soup.select(".re__pr-short-info-item")
        for row in short_info_rows:
            label = safe_text(row.select_one(".title"))
            value = safe_text(row.select_one(".value"))
            if not label or not value:
                continue
            label_l = label.lower()
            if "ngày đăng" in label_l:
                posted_date = value
            elif "ngày hết hạn" in label_l:
                expired_date = value

        specs = {
            "price_raw": None,
            "area_raw": None,
            "bedrooms_raw": None,
            "bathrooms_raw": None,
            "direction": None,
            "balcony_direction": None,
            "furnishing": None,
            "legal_status": None,
            "project_name": None,
            "address_raw": None,
        }

        spec_rows = soup.select(".re__pr-specs-content-item")
        for row in spec_rows:
            key = safe_text(row.select_one(".re__pr-specs-content-item-title"))
            val = safe_text(row.select_one(".re__pr-specs-content-item-value"))
            if not key or not val:
                continue
            key_l = key.lower()
            if "giá" in key_l:
                specs["price_raw"] = val
            elif "diện tích" in key_l:
                specs["area_raw"] = val
            elif "phòng ngủ" in key_l:
                specs["bedrooms_raw"] = val
            elif "phòng tắm" in key_l or "vệ sinh" in key_l:
                specs["bathrooms_raw"] = val
            elif "hướng nhà" in key_l:
                specs["direction"] = val
            elif "hướng ban công" in key_l:
                specs["balcony_direction"] = val
            elif "nội thất" in key_l:
                specs["furnishing"] = val
            elif "pháp lý" in key_l:
                specs["legal_status"] = val
            elif "tên dự án" in key_l:
                specs["project_name"] = val
            elif "địa chỉ" in key_l:
                specs["address_raw"] = val

        # Additional fallbacks from breadcrumb / page summary if present
        if not specs["address_raw"]:
            breadcrumb = [safe_text(x) for x in soup.select(".re__breadcrumb a")]
            breadcrumb = [x for x in breadcrumb if x]
            if breadcrumb:
                specs["address_raw"] = " > ".join(breadcrumb)

        price_vnd = parse_price_to_vnd(specs["price_raw"])
        area_m2 = parse_area_m2(specs["area_raw"])
        bedrooms = parse_int_value(specs["bedrooms_raw"])
        bathrooms = parse_int_value(specs["bathrooms_raw"])
        price_per_m2 = int(price_vnd / area_m2) if price_vnd and area_m2 else None

        raw_record = {
            "source_name": SOURCE_NAME,
            "snapshot_date": self.config.snapshot_date,
            "brand": self.config.brand,
            "project": self.config.project,
            "city": self.config.city,
            "listing_type_raw": listing_type_raw,
            "listing_url": url,
            "title": listing_title,
            "description_text": description,
            "price_raw": specs["price_raw"],
            "area_raw": specs["area_raw"],
            "price_vnd": price_vnd,
            "area_m2": area_m2,
            "price_per_m2_vnd": price_per_m2,
            "bedrooms": bedrooms,
            "bathrooms": bathrooms,
            "direction": specs["direction"],
            "balcony_direction": specs["balcony_direction"],
            "furnishing": specs["furnishing"],
            "legal_status": specs["legal_status"],
            "project_name": specs["project_name"],
            "address_raw": specs["address_raw"],
            "posted_date": posted_date,
            "expired_date": expired_date,
        }
        return raw_record

    def crawl_detail_pages(self, url_rows: List[Dict]) -> List[Dict]:
        all_details, seen_urls = self.load_existing_details()

        for idx, row in enumerate(url_rows, start=1):
            url = row["listing_url"]
            if self.config.resume and url in seen_urls:
                continue

            logging.info("Đang crawl chi tiết %s/%s | %s", idx, len(url_rows), url)
            try:
                detail = self.parse_detail_page(url, row.get("listing_type_raw"))
                if detail:
                    all_details.append(detail)
                    seen_urls.add(url)
            except TimeoutException as exc:
                logging.error("Timeout chi tiết: %s | %s", url, exc)
                self.append_error({
                    "snapshot_date": self.config.snapshot_date,
                    "stage": "detail",
                    "listing_url": url,
                    "error": f"TimeoutException: {exc}",
                })
            except WebDriverException as exc:
                logging.error("WebDriver lỗi tại %s | %s", url, exc)
                self.append_error({
                    "snapshot_date": self.config.snapshot_date,
                    "stage": "detail",
                    "listing_url": url,
                    "error": f"WebDriverException: {exc}",
                })
            except Exception as exc:
                logging.error("Lỗi chi tiết tại %s | %s", url, exc)
                self.append_error({
                    "snapshot_date": self.config.snapshot_date,
                    "stage": "detail",
                    "listing_url": url,
                    "error": repr(exc),
                })

            if idx % self.config.save_every == 0:
                self.save_dataframe(all_details, self.details_raw_path)
                logging.info("Checkpoint details raw: %s records", len(all_details))

        self.save_dataframe(all_details, self.details_raw_path)
        logging.info("Hoàn tất detail crawl | tổng records=%s", len(all_details))
        return all_details

    def build_clean_dataset(self, detail_rows: List[Dict]) -> pd.DataFrame:
        if not detail_rows:
            return pd.DataFrame()

        df = pd.DataFrame(detail_rows).copy()
        # Keep a compact, stable v1 schema for downstream scripts
        df["source_listing_id"] = df["listing_url"].str.extract(r"/(\d+)(?:\?|$)", expand=False)
        df["property_type"] = "apartment"
        df["listing_type"] = "sale"
        df["project_name"] = df["project_name"].fillna(self.config.project)
        df["city"] = df["city"].fillna(self.config.city)
        df["brand"] = df["brand"].fillna(self.config.brand)
        df["title_length"] = df["title"].fillna("").str.len()
        df["description_length"] = df["description_text"].fillna("").str.len()
        df["has_legal_status"] = df["legal_status"].notna().astype(int)
        df["has_furnishing"] = df["furnishing"].notna().astype(int)
        df["is_valid_record"] = (
            df["price_vnd"].notna() &
            df["area_m2"].notna() &
            (df["area_m2"].fillna(0) > 0) &
            df["title"].notna()
        ).astype(int)

        final_cols = [
            "source_name",
            "snapshot_date",
            "source_listing_id",
            "listing_url",
            "city",
            "project_name",
            "brand",
            "property_type",
            "listing_type",
            "title",
            "description_text",
            "price_vnd",
            "price_per_m2_vnd",
            "area_m2",
            "bedrooms",
            "bathrooms",
            "direction",
            "balcony_direction",
            "furnishing",
            "legal_status",
            "address_raw",
            "posted_date",
            "expired_date",
            "title_length",
            "description_length",
            "has_legal_status",
            "has_furnishing",
            "is_valid_record",
        ]

        clean_df = df[final_cols].drop_duplicates(subset=["listing_url"])
        clean_df.to_csv(self.details_clean_path, index=False, encoding="utf-8-sig")
        logging.info("Đã lưu clean CSV: %s | records=%s", self.details_clean_path, len(clean_df))
        return clean_df

    def run(self) -> None:
        try:
            url_rows = self.crawl_list_pages()
            detail_rows = self.crawl_detail_pages(url_rows)
            self.build_clean_dataset(detail_rows)
        finally:
            self.close()


def parse_args() -> CrawlConfig:
    parser = argparse.ArgumentParser(description="Batdongsan crawler v1 | Selenium + CSV")
    parser.add_argument("--base-url", required=True, help="URL trang list của dự án / search result")
    parser.add_argument("--project", required=True, help="Tên project nội bộ")
    parser.add_argument("--city", required=True, help="Tên thành phố / khu vực")
    parser.add_argument("--brand", default="", help="Tên chủ đầu tư / brand")
    parser.add_argument("--output-dir", default="./output", help="Thư mục lưu CSV và log")
    parser.add_argument("--max-pages", type=int, default=50, help="Số trang list tối đa")
    parser.add_argument("--wait-timeout", type=int, default=15, help="Timeout chờ element")
    parser.add_argument("--min-delay", type=float, default=2.0, help="Delay tối thiểu giữa list pages")
    parser.add_argument("--max-delay", type=float, default=4.5, help="Delay tối đa giữa list pages")
    parser.add_argument("--detail-min-delay", type=float, default=0.8, help="Delay tối thiểu giữa detail pages")
    parser.add_argument("--detail-max-delay", type=float, default=1.8, help="Delay tối đa giữa detail pages")
    parser.add_argument("--snapshot-date", default=time.strftime("%Y-%m-%d"), help="Ngày snapshot")
    parser.add_argument("--remote-debug-address", default=None, help="Ví dụ 127.0.0.1:9222")
    parser.add_argument("--headless", action="store_true", help="Chạy headless nếu không dùng Chrome đang mở")
    parser.add_argument("--resume", action="store_true", help="Resume từ CSV đã có")
    parser.add_argument("--save-every", type=int, default=20, help="Bao nhiêu detail records thì checkpoint")

    args = parser.parse_args()
    return CrawlConfig(
        base_url=args.base_url,
        project=args.project,
        city=args.city,
        brand=args.brand,
        output_dir=Path(args.output_dir),
        max_pages=args.max_pages,
        wait_timeout=args.wait_timeout,
        min_delay=args.min_delay,
        max_delay=args.max_delay,
        detail_min_delay=args.detail_min_delay,
        detail_max_delay=args.detail_max_delay,
        snapshot_date=args.snapshot_date,
        remote_debug_address=args.remote_debug_address,
        headless=args.headless,
        resume=args.resume,
        save_every=args.save_every,
    )


if __name__ == "__main__":
    cfg = parse_args()
    setup_logging(cfg.output_dir, cfg.snapshot_date)
    logging.info("Bắt đầu crawl | base_url=%s | project=%s | city=%s", cfg.base_url, cfg.project, cfg.city)
    crawler = BatdongsanCrawlerV1(cfg)
    crawler.run()
    logging.info("Hoàn tất")
