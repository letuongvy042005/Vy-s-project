# =========================================
# IMPORT LIBRARIES
# =========================================

import random
import time
import re
import pandas as pd
import os
from datetime import datetime
import unicodedata
import hashlib
import undetected_chromedriver as uc
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from seleniumbase import Driver
from bs4 import BeautifulSoup
from unidecode import unidecode


driver = Driver(uc=True)
driver.get("https://batdongsan.com.vn")


print("Connected to Chrome")


# =========================================
# HELPER FUNCTIONS
# =========================================

def remove_accents(text):
    """Remove Vietnamese accents using unidecode"""
    return unidecode(text)

def create_slug(project_name):
    """Convert project name to URL slug"""
    # Đặc biệt xử lý một số trường hợp đặc biệt trước
    special_cases = {
        "sola - đảo ánh dương": "sola-dao-anh-duong",
        "the regency phú mỹ hưng": "the-regency-phu-my-hung",
    }

    # Check special cases first (case insensitive)
    lower_name = project_name.lower()
    if lower_name in special_cases:
        return special_cases[lower_name]

    # Remove accents and lowercase
    slug = remove_accents(project_name.lower())

    # Replace special characters
    slug = re.sub(r'[^a-z0-9\s-]', '', slug)  # Only keep a-z, 0-9, space, dash
    slug = re.sub(r'[-_\s]+', '-', slug)  # Replace spaces and underscores with dash
    slug = slug.strip('-')

    return slug

def safe_text(el):
    """Safely get text from a BeautifulSoup element"""
    return el.text.strip() if el else None

def clean_text(text):
    """Clean text: remove extra spaces, newlines, tabs"""
    if not text:
        return None
    # Replace newlines, tabs, multiple spaces with single space
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

def get_number(text):
    """Extract first number from text"""
    if not text:
        return None

    match = re.search(r"\d+\.?\d*", text.replace(",", "."))
    return float(match.group()) if match else None


def parse_price(text):
    """Convert price text (tỷ / triệu) to VND"""
    if not text:
        return None

    num = get_number(text)

    if num is None:
        return None

    if "tỷ" in text.lower():
        num *= 1_000_000_000
    elif "triệu" in text.lower():
        num *= 1_000_000

    return int(num)


def extract_listing_id(url, soup):
    """Extract listing ID from URL or page"""
    # Try from URL first
    match = re.search(r'pr(\d+)', url)
    if match:
        return match.group(1)

    # Try from page (Mã tin)
    ma_tin = soup.find(text=re.compile(r'Mã tin'))
    if ma_tin:
        parent = ma_tin.find_parent()
        if parent:
            text = parent.get_text()
            match = re.search(r'Mã tin\s*(\d+)', text)
            if match:
                return match.group(1)

    return None


def extract_contact_info(soup):
    """Extract contact name and masked phone"""
    contact_name = None
    contact_phone = None

    # Find phone button
    phone_btn = soup.select_one('.re__link-phone, .js__phone')
    if phone_btn:
        # Get contact name from data attribute
        contact_name = phone_btn.get('data-kyc-name')

        # Get phone number from span
        phone_span = phone_btn.select_one('span')
        if phone_span:
            phone_text = safe_text(phone_span)
            # Extract phone pattern (xxx xxx ***)
            match = re.search(r'(\d{4}\s\d{3}\s\*\*\*)', phone_text)
            if match:
                contact_phone = match.group(1)

    return contact_name, contact_phone


# =========================================
# GET LISTINGS FROM SEARCH PAGE
# =========================================

def get_listings():
    cards = driver.find_elements(By.CSS_SELECTOR, "#product-lists-web .re__card-full")

    listings = []

    for card in cards:
        try:
            # Skip promoted ads
            card_class = card.get_attribute("class")
            if "promoted" in card_class:
                continue

            # Skip native sponsored ads
            if card.find_elements(By.CSS_SELECTOR, ".re__native-sponsored-ad"):
                continue

            # Get link
            link = card.find_element(By.CSS_SELECTOR, "a.js__product-link-for-product-id")
            url = link.get_attribute("href")

            if not url or "batdongsan.com.vn" not in url:
                continue

            # Skip expired
            expired = card.find_elements(By.CSS_SELECTOR, "img[src*='expired']")
            if expired:
                continue

            listings.append({
                "listing_type": card.get_attribute("vtp"),
                "url": url
            })
        except:
            pass

    return listings


# =========================================
# COLLECT ALL LISTING URLS FOR A PROJECT
# =========================================

def collect_listing_urls(base_url, project_slug):
    all_listings = []
    seen_urls = set()
    page = 1

    print(f"  Collecting URLs from search pages...")

    while True:
        url = base_url if page == 1 else f"{base_url}/p{page}"

        print(f"    Page {page}...", end=" ")

        try:
            driver.get(url)

            WebDriverWait(driver, 15).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "#product-lists-web"))
            )

            # Đợi thêm 2-3 giây cho card render
            time.sleep(random.uniform(2, 4))

            # Đợi ít nhất 1 card xuất hiện
            try:
                WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, ".re__card-full"))
                )
            except:
                pass

            listings = get_listings()

            new_count = 0
            for item in listings:
                if item["url"] not in seen_urls:
                    seen_urls.add(item["url"])
                    all_listings.append(item)
                    new_count += 1

            print(f"got {new_count} new, total {len(all_listings)}")

            # Nếu không có bài đăng nào ở page đầu tiên → project không tồn tại hoặc sai slug
            if page == 1 and new_count == 0:
                print(f"    No listings found on page 1. Project may not exist.")
                break

            if new_count == 0 and page > 1:
                break

            # Kiểm tra nút next page có tồn tại không
            try:
                next_btn = driver.find_element(By.CSS_SELECTOR, "a.re__pagination-next")
                if "disabled" in next_btn.get_attribute("class"):
                    print(f"    No more pages")
                    break
            except:
                pass

            page += 1

        except Exception as e:
            print(f"\n    Error on page {page}: {e}")
            break

    return all_listings

# =========================================
# CRAWL DETAIL PAGE
# =========================================

def crawl_listing(url, project_name, brand=None):
    try:
        driver.get(url)

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "#product-detail-web"))
        )

        soup = BeautifulSoup(driver.page_source, "html.parser")

        # ===== SOURCE LISTING ID =====
        source_listing_id = extract_listing_id(url, soup)

        # ===== TITLE =====
        titles = soup.select("h1.re__pr-title")
        title = None
        for t in titles:
            text = safe_text(t)
            if text and "mã tin" not in text.lower():
                title = text
                break

        #===== DESCRIPTION =====
        description_raw = safe_text(
            soup.select_one("#product-detail-web .re__pr-description .re__section-body")
        )
        description = clean_text(description_raw)

        # ===== DATES =====
        posted_date = None
        expired_date = None

        rows = soup.select(".re__pr-short-info-item")
        for row in rows:
            label = safe_text(row.select_one(".title"))
            value = safe_text(row.select_one(".value"))

            if not label or not value:
                continue

            label = label.lower()
            if "ngày đăng" in label:
                posted_date = value
            elif "ngày hết hạn" in label:
                expired_date = value

        # ===== PROPERTY SPECS =====
        price_vnd = None
        area_m2 = None
        bedrooms = None
        bathrooms = None
        direction = None
        legal_status = None
        furniture_status = None

        rows = soup.select(".re__pr-specs-content-item")
        for row in rows:
            key = safe_text(row.select_one(".re__pr-specs-content-item-title"))
            val = safe_text(row.select_one(".re__pr-specs-content-item-value"))

            if not key or not val:
                continue

            key = key.lower()

            if "giá" in key:
                price_vnd = parse_price(val)
            elif "diện tích" in key:
                area_m2 = get_number(val)
            elif "phòng ngủ" in key:
                bedrooms = get_number(val)
            elif "phòng tắm" in key or "vệ sinh" in key:
                bathrooms = get_number(val)
            elif "hướng nhà" in key or "hướng ban công" in key:
                direction = val
            elif "pháp lý" in key:
                legal_status = val
            elif "nội thất" in key:
                furniture_status = val

        # ===== CONTACT INFO =====
        contact_name, contact_phone = extract_contact_info(soup)

        # ===== RETURN DATA =====
        return {
            "source_name": "batdongsan.com.vn",
            "snapshot_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "source_listing_id": source_listing_id,
            "listing_url": url,
            "project_name": project_name,
            "listing_type": None,  # Will be filled from search page
            "title": title,
            "description": description,
            "price_total_vnd": price_vnd,
            "area_m2": area_m2,
            "bedrooms": bedrooms,
            "bathrooms": bathrooms,
            "legal_status": legal_status,
            "furniture_status": furniture_status,
            "direction": direction,
            "contact_name": contact_name,
            "contact_phone_masked": contact_phone,
            "posted_at": posted_date,
            "expired_at": expired_date
        }

    except Exception as e:
        print(f"    Error crawling {url}: {e}")
        return None


# =========================================
# CRAWL FULL PROJECT
# =========================================

def crawl_project(project_name, brand=None, checkpoint_file="crawl_progress.csv"):
    print(f"\n{'=' * 60}")
    print(f"Project: {project_name}")

    # Create slug and URL
    slug = create_slug(project_name)
    base_url = f"https://batdongsan.com.vn/nha-dat-ban-{slug}"

    print(f"  Slug: {slug}")
    print(f"  URL: {base_url}")

    # Check if already crawled
    if os.path.exists(checkpoint_file):
        df_check = pd.read_csv(checkpoint_file)
        if project_name in df_check['project_name'].values:
            status = df_check[df_check['project_name'] == project_name]['status'].values[0]
            if status == 'completed':
                print(f"  Already completed. Skipping.")
                return None

    # Collect all listing URLs
    try:
        listings = collect_listing_urls(base_url, slug)

        if not listings:
            print(f"  No listings found for {project_name}")
            # Log failed project
            log_failed_project(project_name, slug, "No listings found")
            return None

        print(f"  Found {len(listings)} unique listings")

        # Crawl each listing
        results = []
        for i, item in enumerate(listings):
            print(f"    Crawling {i + 1}/{len(listings)}...", end=" ")

            data = crawl_listing(item["url"], project_name, brand)

            if data:
                data["listing_type"] = item["listing_type"]
                results.append(data)
                print("OK")
            else:
                print("FAIL")

            # Random delay between listings (3-7 seconds)
            time.sleep(random.uniform(3, 7))

        # Save results
        if results:
            df = pd.DataFrame(results)
            output_file = f"data_{slug}.csv"
            df.to_csv(output_file, index=False, encoding="utf-8-sig")
            print(f"  Saved {len(results)} records to {output_file}")

            # Update checkpoint
            update_checkpoint(project_name, slug, 'completed', len(results))

            return df
        else:
            print(f"  No valid data crawled")
            update_checkpoint(project_name, slug, 'failed', 0)
            return None

    except Exception as e:
        print(f"  Error crawling project: {e}")
        update_checkpoint(project_name, slug, 'error', 0, str(e))
        return None


def update_checkpoint(project_name, slug, status, records_count, error_msg=None):
    """Update checkpoint file"""
    checkpoint_file = "crawl_progress.csv"

    new_record = {
        'project_name': project_name,
        'slug': slug,
        'status': status,
        'records': records_count,
        'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        'error': error_msg if error_msg else ''
    }

    if os.path.exists(checkpoint_file):
        df = pd.read_csv(checkpoint_file)
        # Remove old record if exists
        df = df[df['project_name'] != project_name]
        df = pd.concat([df, pd.DataFrame([new_record])], ignore_index=True)
    else:
        df = pd.DataFrame([new_record])

    df.to_csv(checkpoint_file, index=False, encoding="utf-8-sig")


def log_failed_project(project_name, slug, reason):
    """Log failed projects"""
    log_file = "crawl_log.csv"

    new_record = {
        'project_name': project_name,
        'slug': slug,
        'reason': reason,
        'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    if os.path.exists(log_file):
        df = pd.read_csv(log_file)
        df = pd.concat([df, pd.DataFrame([new_record])], ignore_index=True)
    else:
        df = pd.DataFrame([new_record])

    df.to_csv(log_file, index=False, encoding="utf-8-sig")


# =========================================
# MAIN - CRAWL ALL PROJECTS
# =========================================

def main():
    # List of projects (paste your list here)
    projects = [
        "Mường Thanh Phú Hữu",
        "Chung cư Phú Thọ DMC",
        "Sola - Đảo Ánh Dương",
        "Vinhomes Grand Park",
        "The Regency Phú Mỹ Hưng",
        "The Sculptura",
        "Trellia Cove",
        "Biệt thự Jardin Villas",
        "Vạn Phúc Mansion",
        "Essensia Parkway",
        "Alta Height",
        "Vạn Phúc 1",
        "Sunlake Villas",
        "The Meadow Bình Chánh",
        "Phú Mỹ Hưng L'Arcade",
        "The Opus One - Vinhomes Grand Park",
        "Chung cư Stown Tham Lương",
        "The Aurora Phú Mỹ Hưng",
        "Cityland Center Hills",
        "The Sholi Bình Tân",
        "Glory Heights - Vinhomes Grand Park",
        "Urban Green",
        "Avatar Thủ Đức",
        "Eco Luxury Bình Tân",
        "Lavila Đông Sài Gòn",
        "Vinhomes Green Paradise",
        "9X An Sương",
        "Eaton Park",
        "Thạnh Mỹ Lợi Villas",
        "KDC Đất Nam Tây Lân",
        "KDC Đất Nam An Lạc",
        "The OpusK Residence",
        "The Privia",
        "Salto Residence - Phố Đông Village",
        "Kiều by KITA",
        "Dinh thự The Rivus Elie Saab",
        "Phố Đông Village",
        "Essensia Sky",
        "Happy One Sora",
        "The Glen - Celadon City",
        "Celesta Avenue",
        "Ba Son - Đông Tăng Long Hưng Phúc",
        "Fiato Uptown",
        "The Classia",
        "The Beverly Solari - Vinhomes Grand Park",
        "The Beverly - Vinhomes Grand Park",
        "Shizen Home",
        "The Global City",
        "Moonlight Centre Point",
        "BiTa SmartHome",
        "Zeitgeist City",
        "The Saigon RiverFront",
        "PiCity High Park",
        "Water Bay",
        "Victoria Village",
        "The Origami - Vinhomes Grand Park",
        "Khu đô thị Palm Marina",
        "Khu đô thị Vạn Phúc City",
        "The Metropole Thủ Thiêm",
        "Lavila De Rio",
        "Diyas Sky",
        "Celesta Heights",
        "The 9 Stellars",
        "King Crown Infinity",
        "Eco Green Sài Gòn",
        "Saigon West Broadway",
        "The Antonia",
        "Royal Park Riverside",
        "Prosper Phố Đông",
        "Căn hộ DEFINE",
        "Khải Hoàn Prime",
        "Lux Home Gardens",
        "Golden Valley City",
        "Panomax River Villas",
        "Westgate",
        "Song Minh Residence",
        "River Park Tower",
        "Nam Khang Riverside",
        "Symbio Garden",
        "La Cosmo Residences",
        "De La Sol",
        "Dragon Village",
        "Sài Gòn Eco Town",
        "Hòa Phú Town",
        "The Grand Manhattan",
        "Central Home Saigon",
        "Akari City Nam Long",
        "Vista Riverside Củ Chi",
        "Bình Mỹ Garden",
        "Dream Village",
        "Paris Hoàng Kim",
        "Pier IX",
        "Golden Mall quận 9",
        "Osaka Garden 1",
        "Metro City",
        "Saigon Mystery Villas",
        "Legacy 66",
        "Gold Land Bình Thạnh",
        "Zenity",
        "Metro Star",
        "The Green Town Củ Chi",
        "Long Trường Riverside",
        "Đất Nam Luxury",
        "Sunshine Sky City",
        "Căn hộ Citi Alto",
        "D-one Sài Gòn",
        "Khu dân cư Vạn Đạt Củ Chi",
        "S45 Riverside",
        "Khu dân cư Kim Cương",
        "Khu dân cư BTF Water Park View",
        "Q-Mama House",
        "Căn hộ Citi Grand",
        "Dream Home Riverside",
        "Kingdom 101",
        "Little Village",
        "The Peak Garden",
        "Khu đô thị Cát Lái",
        "City Horse",
        "Bình Tiên Riverside",
        "Thịnh Vượng 2 Residence",
        "Noble Crystal Riverside",
        "Q7 Boulevard",
        "Ny'ah Bình Tây",
        "D-Homme",
        "Centennial",
        "Chung cư Elysian",
        "Hoà Phú Green City",
        "Versatile Home",
        "The Sol Residence",
        "Diamond Centery",
        "Cardinal Court",
        "Crystal Town",
        "Thu Thiem Zeit River",
        "The Opera Residence",
        "The Crest Residence",
        "Grand Marina Saigon",
        "Toplife Tower",
        "Căn hộ D-Aqua",
        "Chung cư MT Eastmark City",
        "Topaz City",
        "Khu dân cư Phú Lợi",
        "Empire City Thủ Thiêm",
        "Diamond City",
        "An Hạ Lotus",
        "Việt Nhân Villa Riverside",
        "Khu dân cư Camellia Garden",
        "Park Vista",
        "Cara Riverview",
        "Mê Linh Point Tower",
        "Khu dân cư Hồng Long",
        "The Sun City Riverview",
        "Chung cư Bông Sao",
        "Vinhomes Golden River Ba Son",
        "KDC Phú Nhuận - Phước Long B",
        "Q7 Saigon Riverside",
        "Mizuki Park",
        "Celadon City"
    ]

    print(f"\n{'=' * 60}")
    print(f"START CRAWLING {len(projects)} PROJECTS")
    print(f"{'=' * 60}")

    all_data = []

    for i, project in enumerate(projects):
        print(f"\nProgress: {i + 1}/{len(projects)}")

        df = crawl_project(project)

        if df is not None:
            all_data.append(df)

        # Random delay between projects (30-60 seconds)
        if i < len(projects) - 1:
            delay = random.uniform(30, 60)
            print(f"\nWaiting {delay:.0f} seconds before next project...")
            time.sleep(delay)

    # Combine all data
    if all_data:
        final_df = pd.concat(all_data, ignore_index=True)
        final_df.to_csv("all_projects_data.csv", index=False, encoding="utf-8-sig")
        print(f"\n{'=' * 60}")
        print(f"COMPLETED! Total records: {len(final_df)}")
        print(f"Saved to: all_projects_data.csv")
    else:
        print("\nNo data collected from any project")

    print(f"{'=' * 60}")

    # ===== ĐÓNG TRÌNH DUYỆT SAU KHI XONG =====
    driver.quit()
    print("Closed browser")


if __name__ == "__main__":
    main()