"""Wrapper naming-consistent for Batdongsan collector.

Giữ entrypoint theo mẫu collect_<source>.py để đồng bộ với các nguồn khác.
"""
from __future__ import annotations

import logging

from batdongsan_crawler_v1 import BatdongsanCrawlerV1, parse_args, setup_logging


def main() -> None:
    cfg = parse_args()
    setup_logging(cfg.output_dir, cfg.snapshot_date)
    logging.info("Bắt đầu crawl | base_url=%s | project=%s | city=%s", cfg.base_url, cfg.project, cfg.city)
    crawler = BatdongsanCrawlerV1(cfg)
    crawler.run()
    logging.info("Hoàn tất")


if __name__ == '__main__':
    main()
