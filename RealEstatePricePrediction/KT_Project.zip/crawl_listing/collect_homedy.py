from __future__ import annotations

import logging
import re
from typing import Dict, List, Optional, Tuple

import pandas as pd
from bs4 import BeautifulSoup

from common_utils import normalize_whitespace
from multisource_helpers import (
    GenericRequestsCrawler,
    HttpCrawlConfig,
    args_to_config,
    build_common_arg_parser,
    count_meaningful_images,
    extract_first_address_like,
    extract_title,
    regex_search,
    safe_next_page_url,
    setup_logging,
    soup_text,
)


def _value_after_label(lines, labels):
    labels = {lbl.lower() for lbl in labels}
    for idx, line in enumerate(lines):
        if (line or '').lower() in labels and idx + 1 < len(lines):
            return lines[idx + 1]
    return None


class HomedyCrawler(GenericRequestsCrawler):
    SOURCE_NAME = "homedy"
    # DETAIL_URL_RE = re.compile(r"homedy\.com/.+-es\d+(?:\?.*)?$", re.I)
    DETAIL_URL_RE = re.compile(
        r"homedy\.com/(?:ban-can-ho|ban-nha-biet-thu-lien-ke|ban-dat-nen-du-an|ban-nha-pho-thuong-mai-shophouse)-[a-z0-9-]+(?:/p\d+)?$|homedy\.com/.+-es\d+(?:\?.*)?$",
        re.I)
    DEFAULT_BASE_URLS = {
        "ha-noi": "https://homedy.com/ban-can-ho-ha-noi",
        "ho-chi-minh": "https://homedy.com/ban-can-ho-tp-ho-chi-minh",
    }
    LIST_URL_HINTS = ("homedy.com/ban-can-ho", "homedy.com/ban-nha-biet-thu-lien-ke", "homedy.com/ban-dat-nen-du-an", "homedy.com/ban-nha-pho-thuong-mai-shophouse")

    def extract_source_listing_id(self, url: str) -> Optional[str]:
        m = re.search(r"-es(\d+)", url)
        return m.group(1) if m else super().extract_source_listing_id(url)

    def parse_list_page(self, soup: BeautifulSoup, page_url: str, page_number: int) -> Tuple[List[Dict], Optional[str]]:
        rows: List[Dict] = []
        seen = set()
        from multisource_helpers import normalized_url

        tab_content = soup.find("div", class_="tab-content")
        if not tab_content:
            return rows, None

        for a in tab_content.find_all("a", href=True):
            url = normalized_url(page_url, a["href"])
            if not self.DETAIL_URL_RE.search(url):
                continue
            if url in seen:
                continue
            title = normalize_whitespace(a.get_text(" ", strip=True))
            if not title or len(title) < 15:
                continue
            seen.add(url)
            rows.append({
                "source_name": self.SOURCE_NAME,
                "snapshot_date": self.config.snapshot_date,
                "city": self.config.city,
                "page_number": page_number,
                "list_page_url": page_url,
                "listing_url": url,
                "title_from_list": title,
            })

        # next_url = safe_next_page_url(soup, page_url, page_number, self.DETAIL_URL_RE, self.LIST_URL_HINTS)
        # TÌM NEXT_URL THỦ CÔNG THAY VÌ DÙNG safe_next_page_url
        next_url = None
        page_nav = soup.find("div", class_="page-nav")
        if page_nav:
            for a in page_nav.find_all("a", href=True):
                href = a.get("href")
                # Tìm link đến trang tiếp theo (vd: /p2, /p3)
                if href and f"/p{page_number + 1}" in href:
                    next_url = normalized_url(page_url, href)
                    break
        return rows, next_url

    def parse_detail_page(self, soup: BeautifulSoup, url: str, listing_context: Dict) -> Optional[Dict]:
        text = soup_text(soup)
        lines = [normalize_whitespace(line) for line in text.split("\n") if normalize_whitespace(line)]

        title = extract_title(soup) or listing_context.get("title_from_list")
        description = regex_search(text, [r"Thông tin mô tả\s*(.*?)\s*Loại hình"], flags=re.I | re.S)

        # Khai báo
        price_raw = None
        price_per_m2_raw = None
        area_raw = None
        image_count = 0

        # Tìm tất cả các short-item
        short_items = soup.find_all("div", class_="short-item")
        for item in short_items:
            span = item.find("span")
            if not span:
                continue
            label = span.get_text(strip=True).lower()

            if label == "giá":
                strong = item.find("strong")
                if strong:
                    price_raw = normalize_whitespace(strong.get_text(" ", strip=True))
                em = item.find("em")
                if em:
                    price_per_m2_raw = normalize_whitespace(em.get_text(" ", strip=True))

            elif label == "diện tích":
                strong = item.find("strong")
                if strong:
                    area_raw = normalize_whitespace(strong.get_text(" ", strip=True))

        # Fallback to regex nếu không tìm thấy
        if not price_raw:
            price_raw = regex_search(text, [r"Giá\s*([^\n]+?)(?=\s*~|\n)"])
        if not price_per_m2_raw:
            price_per_m2_raw = regex_search(text,
                                            [r"~\s*([^\n]+/[mM]2|[^\n]+tr/m2)", r"([\d\.,]+\s*(?:triệu|tỷ|tr)/m2)"])
        if not area_raw:
            area_raw = regex_search(text, [r"Diện tích\s*([^\n]+)"])

        # ĐỊA CHỈ - Dùng BeautifulSoup
        address_raw = None
        address_div = soup.find("div", class_="address")
        if address_div:
            address_raw = normalize_whitespace(address_div.get_text(" ", strip=True))

        # Fallback to helper nếu không tìm thấy
        if not address_raw:
            address_raw = extract_first_address_like(lines, self.config.city)

        # ===== LẤY HƯỚNG NHÀ =====
        direction = None

        # Cách 1: Tìm trong product-attributes (HTML structure)
        attr_items = soup.find_all("div", class_="product-attributes--item")
        for item in attr_items:
            spans = item.find_all("span")
            if len(spans) >= 2:
                label = spans[0].get_text(strip=True).lower()
                value = spans[1].get_text(strip=True)
                if label == "hướng nhà":
                    direction = value
                    break

        # Cách 2: Fallback to regex nếu không tìm thấy
        if not direction:
            direction = regex_search(text, [r"Hướng cửa chính\s*([^\n]+)", r"Hướng nhà\s*([^\n]+)"])

        # Các trường khác
        project_name = regex_search(text, [r"Thuộc dự án\s*([^\n]+)"])
        legal_status = regex_search(text, [r"Tình trạng pháp lý\s*([^\n]+)"])
        furniture_status = regex_search(text, [
            # Trường hợp có cấu trúc "Nội thất: ..."
            r"Nội thất\s*[:;]\s*(.*?)(?=\s*(?:Liên hệ|Giá|Diện tích|Hướng|Pháp lý|Đặc điểm|Tiện ích|Xem thêm|$))",
            r"Tình trạng nội thất\s*[:;]\s*(.*?)(?=\s*(?:Liên hệ|Giá|Diện tích|Hướng|Pháp lý|$))",
            # Trường hợp "bàn giao full nội thất", "nội thất đầy đủ", v.v.
            r"\b(full|đầy đủ|cao cấp|cơ bản|nguyên bản|xịn)\s*(?:nội thất|đồ)?\b",
        ], flags=re.I | re.S)
        bedrooms = regex_search(text, [r"(\d+)\s*phòng ngủ", r"(\d+)PN"])
        bathrooms = regex_search(text, [r"(\d+)\s*(?:wc|vs|vệ sinh|phòng tắm)"])
        posted_at = regex_search(text, [r"Ngày đăng\s*([^\n]+)"])
        updated_at = regex_search(text, [r"Ngày hết hạn\s*([^\n]+)"])
        contact_name = regex_search(text, [r"Liên hệ tư vấn\s*([^\n]+)", r"\b([A-ZÀ-Ỹ][^\n]+)\s+Xem trang cá nhân"])
        contact_phone = regex_search(text, [r"(\d{3,4}\*+\d{0,3})"])

        # Lấy số ảnh chính xác
        image_view = soup.find("div", class_="image-view")
        if image_view:
            for a in image_view.find_all("a", href=True):
                if re.search(r"\.(jpg|jpeg|png|gif|webp)", a["href"].lower()):
                    image_count += 1
        else:
            image_count = 0

        return {
            "source_name": self.SOURCE_NAME,
            "snapshot_date": self.config.snapshot_date,
            "city": self.config.city,
            "listing_url": url,
            "source_listing_id": self.extract_source_listing_id(url),
            "title": title,
            "description_text": description,
            "price_raw": price_raw,
            "price_per_m2_raw": price_per_m2_raw,
            "area_raw": area_raw,
            "bedrooms": bedrooms,
            "bathrooms": bathrooms,
            "floors": None,
            "direction": direction,
            "legal_status": legal_status,
            "furniture_status": furniture_status,
            "project_name": project_name,
            "address_raw": address_raw,
            "posted_at": posted_at,
            "updated_at": updated_at,
            "contact_name": contact_name,
            "contact_phone_masked": contact_phone,
            "image_count": image_count,
        }


def main() -> None:
    parser = build_common_arg_parser(
        "Collect Homedy apartment sale listings -> urls_raw/details_raw/details_clean CSV",
        "homedy",
        HomedyCrawler.default_base_url_for_city("ha-noi"),
    )

    args = parser.parse_args()
    default_url = HomedyCrawler.default_base_url_for_city(args.city)
    if not args.base_url:
        args.base_url = default_url
    config: HttpCrawlConfig = args_to_config(args)
    setup_logging(config.output_dir, "homedy", config.snapshot_date)
    crawler = HomedyCrawler(config)
    crawler.run()


if __name__ == "__main__":
    main()
