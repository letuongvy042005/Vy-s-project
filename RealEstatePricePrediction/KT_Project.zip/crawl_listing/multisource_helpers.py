from __future__ import annotations

import argparse
import logging
import random
import re
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Pattern, Sequence, Tuple
from urllib.parse import urljoin, urlparse, urlunparse

import pandas as pd
import requests
from bs4 import BeautifulSoup
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from common_utils import (
    canonical_key,
    ensure_dir,
    mask_phone,
    normalize_whitespace,
    parse_area_m2,
    parse_int_value,
    parse_price_to_vnd,
    safe_to_datetime,
)


DEFAULT_HEADERS = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "vi,en-US;q=0.9,en;q=0.8",
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/123.0.0.0 Safari/537.36"
    ),
}


@dataclass
class HttpCrawlConfig:
    base_url: str
    city: str
    output_dir: Path
    max_pages: int
    wait_timeout: int
    min_delay: float
    max_delay: float
    detail_min_delay: float
    detail_max_delay: float
    snapshot_date: str
    resume: bool
    save_every: int
    property_type: str = "apartment"
    listing_type: str = "sale"
    label: str = ""
    page_url_template: Optional[str] = None
    # --- THÊM MỚI: danh sách nhiều base URL ---
    # Nếu có giá trị, crawler sẽ loop qua từng URL thay vì chỉ dùng base_url
    base_urls: List[str] = field(default_factory=list)


def setup_logging(output_dir: Path, source_name: str, snapshot_date: str) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    log_path = output_dir / f"{source_name}_crawl_{snapshot_date}.log"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[logging.StreamHandler(sys.stdout), logging.FileHandler(log_path, encoding="utf-8")],
    )


def build_session() -> requests.Session:
    session = requests.Session()
    retry = Retry(
        total=3,
        backoff_factor=1.0,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET", "HEAD"],
        respect_retry_after_header=True,
    )
    adapter = HTTPAdapter(max_retries=retry, pool_connections=10, pool_maxsize=10)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    session.headers.update(DEFAULT_HEADERS)
    return session


def normalized_url(base_url: str, href: str) -> str:
    abs_url = urljoin(base_url, href)
    parsed = urlparse(abs_url)
    return urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", parsed.query, ""))


def soup_text(soup: BeautifulSoup) -> str:
    text = soup.get_text("\n", strip=True)
    text = re.sub(r"\n{2,}", "\n", text)
    return text


def regex_search(text: str, patterns: Sequence[str], flags: int = re.I | re.S) -> Optional[str]:
    for pattern in patterns:
        m = re.search(pattern, text, flags)
        if m:
            for idx in range(1, (m.lastindex or 0) + 1):
                value = normalize_whitespace(m.group(idx))
                if value:
                    return value
    return None


def extract_meta_content(soup: BeautifulSoup, *, prop: Optional[str] = None, name: Optional[str] = None) -> Optional[str]:
    if prop:
        tag = soup.find("meta", attrs={"property": prop})
        if tag and tag.get("content"):
            return normalize_whitespace(tag.get("content"))
    if name:
        tag = soup.find("meta", attrs={"name": name})
        if tag and tag.get("content"):
            return normalize_whitespace(tag.get("content"))
    return None


def extract_title(soup: BeautifulSoup) -> Optional[str]:
    for selector in ["h1", "meta[property='og:title']", "title"]:
        if selector.startswith("meta"):
            value = extract_meta_content(soup, prop="og:title")
        elif selector == "title":
            el = soup.find("title")
            value = normalize_whitespace(el.get_text(" ", strip=True)) if el else None
        else:
            el = soup.select_one(selector)
            value = normalize_whitespace(el.get_text(" ", strip=True)) if el else None
        if value:
            return value
    return None


def extract_first_address_like(lines: Sequence[str], preferred_city: Optional[str] = None) -> Optional[str]:
    city_keywords = ["hà nội", "ha noi", "tp hồ chí minh", "hồ chí minh", "tp hcm", "tphcm", "sài gòn", "sai gon"]
    if preferred_city:
        city_keywords = [preferred_city.lower()] + city_keywords
    for line in lines:
        raw = normalize_whitespace(line)
        if not raw or len(raw) < 8 or len(raw) > 180:
            continue
        line_l = raw.lower()
        if line_l.startswith(("mua bán", "bán căn", "thông tin", "giá", "diện tích", "ngày đăng", "loại tin", "id tin")):
            continue
        if "," not in raw:
            continue
        if any(keyword in line_l for keyword in city_keywords):
            return raw
    return None


def count_meaningful_images(soup: BeautifulSoup) -> int:
    count = 0
    seen = set()
    for img in soup.find_all("img"):
        src = normalize_whitespace(img.get("src") or img.get("data-src") or "")
        if not src:
            continue
        src_l = src.lower()
        if any(x in src_l for x in ["icon", "logo", "avatar", "blank", "spacer", "loading", "facebook", "twitter"]):
            continue
        if src in seen:
            continue
        seen.add(src)
        count += 1
    if count == 0:
        page_text = soup_text(soup)
        m = re.search(r"(\d+)\s*/\s*(\d+)", page_text)
        if m:
            try:
                return int(m.group(2))
            except Exception:
                return 0
    return count


def find_phone_in_text(text: str) -> Optional[str]:
    candidates = re.findall(r"(?:\+?84|0)[\d\.\s\-*]{8,}", text)
    if not candidates:
        return None
    best = sorted(candidates, key=len, reverse=True)[0]
    return mask_phone(best)


def safe_next_page_url(
    soup: BeautifulSoup,
    current_url: str,
    current_page: int,
    detail_url_re: Pattern[str],
    list_url_hints: Sequence[str],
) -> Optional[str]:
    candidates: List[Tuple[int, str]] = []
    for a in soup.find_all("a", href=True):
        href = normalized_url(current_url, a["href"])
        text = normalize_whitespace(a.get_text(" ", strip=True)) or ""
        href_l = href.lower()
        if href == current_url:
            continue
        if detail_url_re.search(href):
            continue
        if list_url_hints and not any(hint in href_l for hint in list_url_hints):
            continue
        score = 0
        if text == str(current_page + 1):
            score += 100
        if text in {">", ">>", "trang sau", "tiếp", "next", "sau"}:
            score += 50
        if re.search(rf"(?:page=|/p|trang[-_/]?){current_page + 1}(?:\D|$)", href_l):
            score += 80
        if score > 0:
            candidates.append((score, href))
    if not candidates:
        return None
    candidates = sorted(candidates, key=lambda x: (-x[0], x[1]))
    return candidates[0][1]


def load_url_list(base_url_file: Optional[str], base_urls_str: Optional[str]) -> List[str]:
    """
    Đọc danh sách URL từ file CSV/TXT hoặc chuỗi phân cách bởi dấu phẩy.
    Trả về list các URL đã lọc trống và loại trùng, giữ thứ tự.

    - base_url_file: đường dẫn tới file .csv (cột 'url') hoặc .txt (mỗi dòng 1 URL)
    - base_urls_str: chuỗi nhiều URL cách nhau dấu phẩy, ví dụ "https://a.com,https://b.com"
    """
    urls: List[str] = []
    seen: set = set()

    def _add(u: str) -> None:
        u = u.strip()
        if u and u not in seen:
            seen.add(u)
            urls.append(u)

    if base_url_file:
        p = Path(base_url_file)
        if not p.exists():
            raise FileNotFoundError(f"--base-url-file không tồn tại: {base_url_file}")
        if p.suffix.lower() == ".csv":
            df = pd.read_csv(p, encoding="utf-8-sig")
            # Chấp nhận cột 'url' hoặc cột đầu tiên
            col = "url" if "url" in df.columns else df.columns[0]
            for v in df[col].dropna().astype(str):
                _add(v)
        else:
            # .txt hoặc các định dạng văn bản khác: mỗi dòng 1 URL
            for line in p.read_text(encoding="utf-8").splitlines():
                _add(line)

    if base_urls_str:
        for u in base_urls_str.split(","):
            _add(u)

    return urls


class GenericRequestsCrawler:
    SOURCE_NAME = "source"
    DETAIL_URL_RE: Pattern[str] = re.compile(r"$")
    DEFAULT_BASE_URLS: Dict[str, str] = {}
    LIST_URL_HINTS: Sequence[str] = ()
    DEFAULT_CITY = "ha-noi"

    def __init__(self, config: HttpCrawlConfig):
        self.config = config
        self.session = build_session()
        label_part = f"_{config.label}" if config.label else ""
        prefix = f"{self.SOURCE_NAME}_{config.property_type}_{config.listing_type}_{config.city}_{config.snapshot_date}{label_part}"
        self.urls_raw_path = config.output_dir / f"{prefix}_urls_raw.csv"
        self.details_raw_path = config.output_dir / f"{prefix}_details_raw.csv"
        self.details_clean_path = config.output_dir / f"{prefix}_details_clean.csv"
        self.errors_path = config.output_dir / f"{prefix}_errors.csv"

    @classmethod
    def default_base_url_for_city(cls, city: str) -> Optional[str]:
        return cls.DEFAULT_BASE_URLS.get(city) or cls.DEFAULT_BASE_URLS.get(cls.DEFAULT_CITY)

    def random_sleep(self, min_delay: float, max_delay: float) -> None:
        time.sleep(random.uniform(min_delay, max_delay))

    def save_dataframe(self, rows: List[Dict], path: Path) -> None:
        pd.DataFrame(rows).to_csv(path, index=False, encoding="utf-8-sig")

    def append_error(self, row: Dict) -> None:
        pd.DataFrame([row]).to_csv(
            self.errors_path,
            mode="a",
            header=not self.errors_path.exists(),
            index=False,
            encoding="utf-8-sig",
        )

    def load_existing_urls(self) -> Tuple[List[Dict], set]:
        if self.config.resume and self.urls_raw_path.exists():
            df = pd.read_csv(self.urls_raw_path)
            return df.to_dict("records"), set(df["listing_url"].dropna().astype(str).tolist())
        return [], set()

    def load_existing_details(self) -> Tuple[List[Dict], set]:
        if self.config.resume and self.details_raw_path.exists():
            df = pd.read_csv(self.details_raw_path)
            return df.to_dict("records"), set(df["listing_url"].dropna().astype(str).tolist())
        return [], set()

    def fetch_soup(self, url: str) -> Tuple[BeautifulSoup, requests.Response]:
        response = self.session.get(url, timeout=self.config.wait_timeout)
        response.raise_for_status()
        return BeautifulSoup(response.text, "html.parser"), response

    def parse_list_page(self, soup: BeautifulSoup, page_url: str, page_number: int) -> Tuple[List[Dict], Optional[str]]:
        raise NotImplementedError

    def parse_detail_page(self, soup: BeautifulSoup, url: str, listing_context: Dict) -> Optional[Dict]:
        raise NotImplementedError

    def extract_source_listing_id(self, url: str) -> Optional[str]:
        m = re.search(r"(\d+)(?:\.html|\.htm|$)", url)
        return m.group(1) if m else None

    def _crawl_list_pages_single(
        self,
        start_url: str,
        all_rows: List[Dict],
        seen_urls: set,
    ) -> List[Dict]:
        """
        Crawl list pages bắt đầu từ start_url.
        Ghi thẳng vào all_rows và seen_urls (in-place) để tích lũy qua nhiều base URL.
        Trả về list các row mới thêm được trong lần gọi này.
        """
        visited_pages: set = set()
        current_url: Optional[str] = start_url
        page_number = 1
        stagnant = 0
        new_rows_this_run: List[Dict] = []

        while current_url and page_number <= self.config.max_pages:
            if current_url in visited_pages:
                break
            visited_pages.add(current_url)
            logging.info("%s | [%s] list page %s | %s", self.SOURCE_NAME, start_url, page_number, current_url)
            try:
                soup, response = self.fetch_soup(current_url)
                self.random_sleep(self.config.min_delay, self.config.max_delay)
                page_rows, next_url = self.parse_list_page(soup, current_url, page_number)
                for row in page_rows:
                    row.setdefault("http_status", response.status_code)
                new_rows = [row for row in page_rows if row.get("listing_url") and row["listing_url"] not in seen_urls]
                for row in new_rows:
                    seen_urls.add(row["listing_url"])
                all_rows.extend(new_rows)
                new_rows_this_run.extend(new_rows)
                # Lưu định kỳ
                self.save_dataframe(all_rows, self.urls_raw_path)
                logging.info(
                    "%s | page=%s | found=%s | new=%s | total=%s",
                    self.SOURCE_NAME, page_number, len(page_rows), len(new_rows), len(seen_urls),
                )
                stagnant = stagnant + 1 if not new_rows else 0
                if stagnant >= 2:
                    logging.info("%s | 2 trang liên tiếp không có URL mới -> dừng", self.SOURCE_NAME)
                    break
                if self.config.page_url_template and page_number < self.config.max_pages:
                    next_url = self.config.page_url_template.format(page=page_number + 1, city=self.config.city)
                current_url = next_url
                page_number += 1
            except Exception as exc:
                logging.error("%s | lỗi list page %s | %s", self.SOURCE_NAME, current_url, exc)
                self.append_error({
                    "snapshot_date": self.config.snapshot_date,
                    "stage": "list",
                    "listing_url": current_url,
                    "error": repr(exc),
                })
                break

        return new_rows_this_run

    def crawl_list_pages(self) -> List[Dict]:
        """
        Crawl list pages từ một hoặc nhiều base URL.

        Nếu config.base_urls có giá trị -> loop qua từng URL trong danh sách đó.
        Nếu không -> dùng config.base_url như cũ (backward compatible).

        Tất cả URL listing tích lũy vào 1 file urls_raw duy nhất,
        dedup theo listing_url trong suốt quá trình.
        """
        all_rows, seen_urls = self.load_existing_urls()

        # Xác định danh sách base URL cần crawl
        base_url_list = self.config.base_urls if self.config.base_urls else [self.config.base_url]

        total = len(base_url_list)
        for i, start_url in enumerate(base_url_list, start=1):
            if not start_url:
                continue
            logging.info(
                "%s | === Bắt đầu base URL %s/%s: %s ===",
                self.SOURCE_NAME, i, total, start_url,
            )
            self._crawl_list_pages_single(start_url, all_rows, seen_urls)

        logging.info("%s | Tổng URL listing sau khi crawl tất cả base URL: %s", self.SOURCE_NAME, len(all_rows))
        return all_rows

    def crawl_detail_pages(self, url_rows: List[Dict]) -> List[Dict]:
        all_details, seen_urls = self.load_existing_details()
        for idx, row in enumerate(url_rows, start=1):
            url = row.get("listing_url")
            if not url:
                continue
            if self.config.resume and url in seen_urls:
                continue
            logging.info("%s | detail %s/%s | %s", self.SOURCE_NAME, idx, len(url_rows), url)
            try:
                soup, _ = self.fetch_soup(url)
                self.random_sleep(self.config.detail_min_delay, self.config.detail_max_delay)
                detail = self.parse_detail_page(soup, url, row)
                if detail:
                    all_details.append(detail)
                    seen_urls.add(url)
            except Exception as exc:
                logging.error("%s | lỗi detail %s | %s", self.SOURCE_NAME, url, exc)
                self.append_error({
                    "snapshot_date": self.config.snapshot_date,
                    "stage": "detail",
                    "listing_url": url,
                    "error": repr(exc),
                })
            if idx % self.config.save_every == 0:
                self.save_dataframe(all_details, self.details_raw_path)
        self.save_dataframe(all_details, self.details_raw_path)
        return all_details

    def build_clean_dataset(self, detail_rows: List[Dict]) -> pd.DataFrame:
        if not detail_rows:
            empty_df = pd.DataFrame()
            empty_df.to_csv(self.details_clean_path, index=False, encoding="utf-8-sig")
            return empty_df

        df = pd.DataFrame(detail_rows).copy()
        if "source_listing_id" not in df.columns:
            df["source_listing_id"] = df["listing_url"].astype(str).apply(self.extract_source_listing_id)
        if "price_total_vnd" not in df.columns:
            df["price_total_vnd"] = df.get("price_raw", pd.Series([None] * len(df))).apply(parse_price_to_vnd)
        else:
            df["price_total_vnd"] = df["price_total_vnd"].fillna(df.get("price_raw", pd.Series([None] * len(df))).apply(parse_price_to_vnd))

        area_tuples = df.get("area_raw", pd.Series([None] * len(df))).apply(parse_area_m2)
        if "area_m2" not in df.columns:
            df["area_m2"] = area_tuples.apply(lambda x: x[0])
        else:
            df["area_m2"] = pd.to_numeric(df["area_m2"], errors="coerce").fillna(area_tuples.apply(lambda x: x[0]))
        if "width_m" not in df.columns:
            df["width_m"] = area_tuples.apply(lambda x: x[1])
        if "length_m" not in df.columns:
            df["length_m"] = area_tuples.apply(lambda x: x[2])

        if "price_per_m2_vnd" not in df.columns:
            df["price_per_m2_vnd"] = None
        if "price_per_m2_raw" in df.columns:
            ppm2_raw = df["price_per_m2_raw"].apply(parse_price_to_vnd)
            df["price_per_m2_vnd"] = df["price_per_m2_vnd"].fillna(ppm2_raw)
        missing_ppm2 = df["price_per_m2_vnd"].isna()
        df.loc[missing_ppm2, "price_per_m2_vnd"] = (
            df.loc[missing_ppm2, "price_total_vnd"] / df.loc[missing_ppm2, "area_m2"]
        )

        for col in ["bedrooms", "bathrooms", "floors", "image_count"]:
            if col not in df.columns:
                df[col] = None
            df[col] = df[col].apply(parse_int_value)

        for col in [
            "district", "ward", "street", "project_name", "direction",
            "legal_status", "furniture_status", "contact_name", "contact_phone_masked",
            "latitude", "longitude", "posted_at", "updated_at",
        ]:
            if col not in df.columns:
                df[col] = None

        if "address_raw" not in df.columns:
            df["address_raw"] = None
        if "title" not in df.columns:
            df["title"] = None
        if "description_text" not in df.columns:
            df["description_text"] = None

        df["source_name"] = self.SOURCE_NAME
        df["snapshot_date"] = self.config.snapshot_date
        df["city"] = df.get("city", pd.Series([self.config.city] * len(df))).fillna(self.config.city)
        df["property_type"] = self.config.property_type
        df["listing_type"] = self.config.listing_type
        df["contact_phone_masked"] = df["contact_phone_masked"].apply(mask_phone)
        df["title_length"] = df["title"].fillna("").astype(str).str.len()
        df["description_length"] = df["description_text"].fillna("").astype(str).str.len()
        df["has_legal_status"] = df["legal_status"].notna().astype(int)
        df["has_furniture_status"] = df["furniture_status"].notna().astype(int)
        df["posted_at"] = df["posted_at"].apply(lambda x: safe_to_datetime(x).strftime("%Y-%m-%d") if safe_to_datetime(x) is not None else x)
        df["updated_at"] = df["updated_at"].apply(lambda x: safe_to_datetime(x).strftime("%Y-%m-%d") if safe_to_datetime(x) is not None else x)
        df["is_valid_record"] = (
            df["title"].notna() & df["listing_url"].notna() & df["price_total_vnd"].notna() & df["area_m2"].notna() & (df["area_m2"].fillna(0) > 0)
        ).astype(int)
        df["canonical_key"] = df.apply(lambda row: canonical_key(row.to_dict()), axis=1)

        final_cols = [
            "source_name", "snapshot_date", "source_listing_id", "listing_url", "city", "district", "ward", "street", "project_name",
            "property_type", "listing_type", "title", "description_text", "price_raw", "price_total_vnd", "price_per_m2_raw", "price_per_m2_vnd",
            "area_raw", "area_m2", "width_m", "length_m", "bedrooms", "bathrooms", "floors", "legal_status", "furniture_status", "direction",
            "contact_name", "contact_phone_masked", "posted_at", "updated_at", "address_raw", "latitude", "longitude", "image_count",
            "title_length", "description_length", "has_legal_status", "has_furniture_status", "is_valid_record", "canonical_key"
        ]
        for col in final_cols:
            if col not in df.columns:
                df[col] = None
        clean_df = df[final_cols].drop_duplicates(subset=["source_listing_id"], keep="first")
        clean_df.to_csv(self.details_clean_path, index=False, encoding="utf-8-sig")
        logging.info("%s | saved clean CSV: %s | records=%s", self.SOURCE_NAME, self.details_clean_path, len(clean_df))
        return clean_df

    def run(self) -> Tuple[List[Dict], List[Dict], pd.DataFrame]:
        url_rows = self.crawl_list_pages()
        detail_rows = self.crawl_detail_pages(url_rows)
        clean_df = self.build_clean_dataset(detail_rows)
        return url_rows, detail_rows, clean_df


def build_common_arg_parser(description: str, source_name: str, default_base_url: Optional[str]) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("--base-url", default=default_base_url,
                        help="URL danh sách đơn lẻ. Bỏ qua nếu dùng --base-url-file hoặc --base-urls.")
    parser.add_argument(
        "--base-url-file", default=None,
        help=(
            "Đường dẫn tới file CSV (có cột 'url') hoặc TXT (mỗi dòng 1 URL) "
            "chứa danh sách nhiều base URL cần crawl. "
            "Mỗi URL được crawl tối đa --max-pages trang, "
            "kết quả gộp vào 1 bộ CSV duy nhất, tự động dedup theo listing_url."
        ),
    )
    parser.add_argument(
        "--base-urls", default=None,
        help=(
            "Nhiều URL cách nhau bằng dấu phẩy, ví dụ: "
            "'https://homedy.com/du-an-a,https://homedy.com/du-an-b'. "
            "Có thể dùng cùng với --base-url-file (sẽ được gộp lại)."
        ),
    )
    parser.add_argument("--city", default="ha-noi")
    parser.add_argument("--output-dir", default=f"./output/{source_name}")
    parser.add_argument("--max-pages", type=int, default=20)
    parser.add_argument("--snapshot-date", default=pd.Timestamp.today().strftime("%Y-%m-%d"))
    parser.add_argument("--wait-timeout", type=int, default=25)
    parser.add_argument("--min-delay", type=float, default=1.0)
    parser.add_argument("--max-delay", type=float, default=2.2)
    parser.add_argument("--detail-min-delay", type=float, default=0.8)
    parser.add_argument("--detail-max-delay", type=float, default=1.8)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--save-every", type=int, default=20)
    parser.add_argument("--property-type", default="apartment")
    parser.add_argument("--listing-type", default="sale")
    parser.add_argument("--label", default="")
    parser.add_argument("--page-url-template", default=None,
                        help="Optional template URL có {page} và {city}")
    return parser


def args_to_config(args: argparse.Namespace) -> HttpCrawlConfig:
    # Giải quyết danh sách base URL
    multi_urls = load_url_list(
        base_url_file=getattr(args, "base_url_file", None),
        base_urls_str=getattr(args, "base_urls", None),
    )

    # Nếu có danh sách multi-url thì base_url chính = phần tử đầu tiên (để backward compat)
    # Nếu không có thì dùng --base-url như cũ
    effective_base_url = args.base_url or (multi_urls[0] if multi_urls else None) or ""

    return HttpCrawlConfig(
        base_url=effective_base_url,
        city=args.city,
        output_dir=Path(args.output_dir),
        max_pages=args.max_pages,
        wait_timeout=args.wait_timeout,
        min_delay=args.min_delay,
        max_delay=args.max_delay,
        detail_min_delay=args.detail_min_delay,
        detail_max_delay=args.detail_max_delay,
        snapshot_date=args.snapshot_date,
        resume=args.resume,
        save_every=args.save_every,
        property_type=args.property_type,
        listing_type=args.listing_type,
        label=args.label,
        page_url_template=args.page_url_template,
        base_urls=multi_urls,  # Danh sách đầy đủ, crawler sẽ loop qua
    )
