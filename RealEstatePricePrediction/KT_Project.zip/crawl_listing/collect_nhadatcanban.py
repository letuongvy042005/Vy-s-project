from __future__ import annotations

import re
from typing import Dict, List, Optional, Tuple

from bs4 import BeautifulSoup

from common_utils import normalize_whitespace
from multisource_helpers import (
    GenericRequestsCrawler,
    HttpCrawlConfig,
    args_to_config,
    build_common_arg_parser,
    count_meaningful_images,
    extract_first_address_like,
    extract_title,
    regex_search,
    safe_next_page_url,
    setup_logging,
    soup_text,
)


def _value_after_label(lines, labels):
    labels = {lbl.lower() for lbl in labels}
    for idx, line in enumerate(lines):
        if (line or '').lower() in labels and idx + 1 < len(lines):
            return lines[idx + 1]
    return None


class NhadatcanbanCrawler(GenericRequestsCrawler):
    SOURCE_NAME = "nhadatcanban"
    DETAIL_URL_RE = re.compile(r"nhadatcanban\.com\.vn/.+-\d+\.html(?:\?.*)?$", re.I)
    DEFAULT_BASE_URLS = {
        "ha-noi": "https://nhadatcanban.com.vn/can-ho-can-ban-tai-ha-noi",
        "ho-chi-minh": "https://nhadatcanban.com.vn/can-ho-can-ban-tai-ho-chi-minh",
    }
    LIST_URL_HINTS = ("nhadatcanban.com.vn/can-ho-can-ban",)

    def parse_list_page(self, soup: BeautifulSoup, page_url: str, page_number: int) -> Tuple[List[Dict], Optional[str]]:
        rows: List[Dict] = []
        seen = set()
        from multisource_helpers import normalized_url

        for a in soup.find_all("a", href=True):
            url = normalized_url(page_url, a["href"])
            if not self.DETAIL_URL_RE.search(url):
                continue
            if url in seen:
                continue
            title = normalize_whitespace(a.get_text(" ", strip=True))
            if not title or len(title) < 12:
                continue
            seen.add(url)
            rows.append({
                "source_name": self.SOURCE_NAME,
                "snapshot_date": self.config.snapshot_date,
                "city": self.config.city,
                "page_number": page_number,
                "list_page_url": page_url,
                "listing_url": url,
                "title_from_list": title,
            })
        next_url = safe_next_page_url(soup, page_url, page_number, self.DETAIL_URL_RE, self.LIST_URL_HINTS)
        return rows, next_url

    def parse_detail_page(self, soup: BeautifulSoup, url: str, listing_context: Dict) -> Optional[Dict]:
        text = soup_text(soup)
        lines = [normalize_whitespace(line) for line in text.split("\n") if normalize_whitespace(line)]
        title = extract_title(soup) or listing_context.get("title_from_list")
        price_raw = regex_search(text, [r"\n([\d\.,]+\s*(?:tỷ|triệu))\s*\d+[\.,]?\d*\s*m²", r"Giá\s*:?\s*([\d\.,]+\s*(?:tỷ|triệu))"])
        area_raw = _value_after_label(lines, ["Diện tích"]) or regex_search(text, [r"\n[\d\.,]+\s*(?:tỷ|triệu)\s*(\d+[\.,]?\d*\s*m²)", r"Diện tích\s*([\d\.,]+\s*m²)"])
        description = regex_search(text, [r"#.*?\n[\d\.,]+\s*(?:tỷ|triệu).*?\n(.*?)##\s*Đặc điểm"], flags=re.I | re.S)
        address_raw = _value_after_label(lines, ["Địa chỉ"]) or regex_search(text, [r"Địa chỉ\s*([^\n]+?)(?=\s+Vị trí|\nVị trí)"])
        if not address_raw:
            address_raw = extract_first_address_like(lines, self.config.city)
        legal_status = _value_after_label(lines, ["Pháp lý"]) or regex_search(text, [r"Pháp lý\s*([^\n]+)"])
        direction = _value_after_label(lines, ["Hướng"]) or regex_search(text, [r"Hướng\s*([^\n]+)"])
        contact_name = _value_after_label(lines, ["Người đăng"]) or regex_search(text, [r"Người đăng\s*([^\n]+?)(?=\s+Điện thoại|\nĐiện thoại)"])
        contact_phone = _value_after_label(lines, ["Điện thoại"]) or regex_search(text, [r"Điện thoại\s*([^\n]+)"])
        posted_at = regex_search(text, [r"Ngày\s*([0-9]{1,2}/[0-9]{1,2}/[0-9]{4})"])
        bedrooms = regex_search(text, [r"(\d+)\s*phòng ngủ", r"(\d+)\s*phòng"])
        bathrooms = regex_search(text, [r"(\d+)\s*phòng tắm", r"(\d+)\s*wc"])
        image_count = count_meaningful_images(soup)
        return {
            "source_name": self.SOURCE_NAME,
            "snapshot_date": self.config.snapshot_date,
            "city": self.config.city,
            "listing_url": url,
            "source_listing_id": self.extract_source_listing_id(url),
            "title": title,
            "description_text": description,
            "price_raw": price_raw,
            "area_raw": area_raw,
            "bedrooms": bedrooms,
            "bathrooms": bathrooms,
            "floors": None,
            "direction": direction,
            "legal_status": legal_status,
            "furniture_status": None,
            "project_name": None,
            "address_raw": address_raw,
            "posted_at": posted_at,
            "updated_at": None,
            "contact_name": contact_name,
            "contact_phone_masked": contact_phone,
            "image_count": image_count,
        }


def main() -> None:
    parser = build_common_arg_parser(
        "Collect Nhadatcanban apartment sale listings -> urls_raw/details_raw/details_clean CSV",
        "nhadatcanban",
        NhadatcanbanCrawler.default_base_url_for_city("ha-noi"),
    )
    args = parser.parse_args()
    default_url = NhadatcanbanCrawler.default_base_url_for_city(args.city)
    if not args.base_url:
        args.base_url = default_url
    config: HttpCrawlConfig = args_to_config(args)
    setup_logging(config.output_dir, "nhadatcanban", config.snapshot_date)
    crawler = NhadatcanbanCrawler(config)
    crawler.run()


if __name__ == "__main__":
    main()
