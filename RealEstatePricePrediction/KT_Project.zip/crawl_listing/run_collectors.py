from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List

import yaml

SCRIPT_DIR = Path(__file__).resolve().parent


def load_yaml(path: str | Path) -> Dict[str, Any]:
    with open(path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f) or {}


def run_cmd(cmd: List[str]) -> None:
    print('[RUN]', ' '.join(cmd))
    subprocess.run(cmd, check=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description='Run collection-only multisource bundle')
    parser.add_argument('--config', default=str(SCRIPT_DIR / 'config.collection.example.yaml'))
    parser.add_argument('--only-sources', default='', help='Comma-separated list, e.g. batdongsan,homedy')
    parser.add_argument('--override-snapshot-date', default=None)
    return parser.parse_args()


def enabled_sources(cfg: Dict[str, Any], only_sources: str) -> Dict[str, bool]:
    src_cfg = cfg.get('sources', {})
    enabled = {k: bool(v) for k, v in src_cfg.items()}
    if only_sources.strip():
        allow = {s.strip() for s in only_sources.split(',') if s.strip()}
        enabled = {k: (k in allow) for k in enabled.keys()}
    return enabled


def main() -> None:
    args = parse_args()
    cfg = load_yaml(args.config)
    python = sys.executable

    snapshot_date = args.override_snapshot_date or cfg.get('project', {}).get('snapshot_date')
    if not snapshot_date:
        raise SystemExit('Thiếu project.snapshot_date trong config hoặc --override-snapshot-date')

    paths = cfg.get('paths', {})
    output_root = paths.get('crawl_output_root', './output')

    crawl = cfg.get('crawl', {})
    common_flags = [
        '--snapshot-date', snapshot_date,
        '--wait-timeout', str(crawl.get('wait_timeout', 25)),
        '--min-delay', str(crawl.get('min_delay', 1.0)),
        '--max-delay', str(crawl.get('max_delay', 2.2)),
        '--detail-min-delay', str(crawl.get('detail_min_delay', 0.8)),
        '--detail-max-delay', str(crawl.get('detail_max_delay', 1.8)),
        '--save-every', str(crawl.get('save_every', 20)),
        '--property-type', str(crawl.get('property_type', 'apartment')),
        '--listing-type', str(crawl.get('listing_type', 'sale')),
    ]
    if crawl.get('resume', True):
        common_flags.append('--resume')

    enabled = enabled_sources(cfg, args.only_sources)

    # -----------------------------------------------------------------------
    # 1) Batdongsan targets: dùng explicit list vì cần custom base_url/project
    # -----------------------------------------------------------------------
    # batdongsan_crawler_v1.py không có --property-type và --listing-type
    # nên phải lọc ra trước khi truyền common_flags
    BATDONGSAN_UNSUPPORTED = {'--property-type', '--listing-type'}

    def _batdongsan_flags(flags: list) -> list:
        result = []
        skip_next = False
        for token in flags:
            if skip_next:
                skip_next = False
                continue
            if token in BATDONGSAN_UNSUPPORTED:
                skip_next = True
                continue
            result.append(token)
        return result

    if enabled.get('batdongsan', False):
        for target in cfg.get('batdongsan_targets', []):
            cmd = [
                python, str(SCRIPT_DIR / 'batdongsan_crawler_v1.py'),
                '--base-url', target['base_url'],
                '--project', target.get('project', 'unknown-project'),
                '--city', target['city'],
                '--brand', target.get('brand', ''),
                '--output-dir', str(Path(output_root) / 'batdongsan'),
                '--max-pages', str(target.get('max_pages', crawl.get('max_pages', 20))),
            ] + _batdongsan_flags(common_flags)
            remote = target.get('remote_debug_address', crawl.get('remote_debug_address'))
            if remote:
                cmd.extend(['--remote-debug-address', str(remote)])
            elif crawl.get('headless', False):
                cmd.append('--headless')
            run_cmd(cmd)

    # -----------------------------------------------------------------------
    # 2) Generic request-based sources: homedy, nhadatcanban
    #    (đã bỏ alonhadat và chotot theo yêu cầu)
    # -----------------------------------------------------------------------
    source_script_map = {
        'homedy':       'collect_homedy.py',
        'nhadatcanban': 'collect_nhadatcanban.py',
    }

    generic_cfg = cfg.get('generic_sources', {})

    for source_name, script_name in source_script_map.items():
        if not enabled.get(source_name, False):
            continue

        source_cfg = generic_cfg.get(source_name, {})
        cities = source_cfg.get('cities', cfg.get('project', {}).get('cities', ['ha-noi']))

        # --- Xác định base_url_file (nếu có) ---
        # Ưu tiên: source_cfg['base_url_file'] > source_cfg['base_urls'] > các city URL mặc định
        base_url_file = source_cfg.get('base_url_file')
        base_urls_inline = source_cfg.get('base_urls')  # list hoặc string trong yaml

        for city in cities:
            cmd = [
                python, str(SCRIPT_DIR / script_name),
                '--city', city,
                '--output-dir', str(Path(output_root) / source_name),
                '--max-pages', str(source_cfg.get('max_pages', crawl.get('max_pages', 20))),
            ] + common_flags

            # Truyền file danh sách URL nếu có
            if base_url_file:
                cmd.extend(['--base-url-file', str(base_url_file)])
            elif base_urls_inline:
                # Nếu trong yaml là list, join lại bằng dấu phẩy
                if isinstance(base_urls_inline, list):
                    cmd.extend(['--base-urls', ','.join(str(u) for u in base_urls_inline)])
                else:
                    cmd.extend(['--base-urls', str(base_urls_inline)])
            elif source_cfg.get('base_url'):
                # Backward compat: vẫn hỗ trợ base_url đơn lẻ trong yaml
                cmd.extend(['--base-url', str(source_cfg['base_url'])])
            # Nếu không có gì -> script tự dùng DEFAULT_BASE_URLS theo city

            if source_cfg.get('label'):
                cmd.extend(['--label', str(source_cfg['label'])])
            if source_cfg.get('page_url_template'):
                cmd.extend(['--page-url-template', str(source_cfg['page_url_template'])])

            run_cmd(cmd)


if __name__ == '__main__':
    main()