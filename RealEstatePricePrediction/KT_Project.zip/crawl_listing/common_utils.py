from __future__ import annotations

import json
import math
import os
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import pandas as pd

STANDARD_COLUMNS: List[str] = [
    "source_name",
    "snapshot_date",
    "source_listing_id",
    "listing_url",
    "city",
    "district",
    "ward",
    "street",
    "project_name",
    "property_type",
    "listing_type",
    "title",
    "description_text",
    "price_total_vnd",
    "price_per_m2_vnd",
    "area_m2",
    "width_m",
    "length_m",
    "bedrooms",
    "bathrooms",
    "floors",
    "legal_status",
    "furniture_status",
    "direction",
    "contact_name",
    "contact_phone_masked",
    "posted_at",
    "updated_at",
    "latitude",
    "longitude",
    "image_count",
    "title_length",
    "description_length",
    "has_legal_status",
    "has_furniture_status",
    "is_valid_record",
    "canonical_key",
]


def ensure_dir(path: Path | str) -> Path:
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path



def normalize_whitespace(text: Optional[str]) -> Optional[str]:
    if text is None:
        return None
    text = re.sub(r"\s+", " ", str(text)).strip()
    return text or None



def slugify(text: str) -> str:
    text = normalize_whitespace(text or "") or ""
    text = text.lower()
    text = re.sub(r"[^0-9a-zA-ZÀ-ỹ]+", "-", text)
    text = re.sub(r"-+", "-", text).strip("-")
    return text or "unknown"



def mask_phone(text: Optional[str]) -> Optional[str]:
    if not text:
        return None
    digits = re.sub(r"\D", "", text)
    if len(digits) < 7:
        return normalize_whitespace(text)
    return digits[:3] + "***" + digits[-3:]



def parse_float_vi(text: Optional[str]) -> Optional[float]:
    if text is None:
        return None
    if isinstance(text, (int, float)) and not pd.isna(text):
        return float(text)
    if not text:
        return None
    s = normalize_whitespace(str(text).lower()) or ""
    s = s.replace("m²", "m2")
    match = re.search(r"\d+[\.,]?\d*", s)
    if not match:
        return None
    token = match.group(0)
    if "," in token and "." in token:
        token = token.replace(".", "").replace(",", ".")
    elif "," in token:
        token = token.replace(",", ".")
    try:
        return float(token)
    except ValueError:
        return None



def parse_price_to_vnd(text: Optional[str]) -> Optional[int]:
    if not text:
        return None
    s = normalize_whitespace(text.lower()) or ""
    if not s:
        return None
    if any(x in s for x in ["thỏa thuận", "thoả thuận", "liên hệ", "lien he", "liên lạc"]):
        return None

    base = re.split(r"-|–|—|~|đến", s)[0].strip()
    num = parse_float_vi(base)
    if num is None:
        return None

    if "tỷ" in base or "ty" in base:
        return int(num * 1_000_000_000)
    if "triệu" in base or "trieu" in base:
        return int(num * 1_000_000)
    if "nghìn" in base or "ngan" in base:
        return int(num * 1_000)
    if "vnđ" in base or "vnd" in base or "đ" in base:
        return int(num)
    return None



def parse_area_m2(text: Optional[str]) -> Tuple[Optional[float], Optional[float], Optional[float]]:
    if not text:
        return None, None, None
    s = normalize_whitespace(text.lower()) or ""
    dim = re.search(r"(\d+[\.,]?\d*)\s*[x×]\s*(\d+[\.,]?\d*)", s)
    if dim:
        a = parse_float_vi(dim.group(1))
        b = parse_float_vi(dim.group(2))
        if a and b:
            return round(a * b, 2), round(a, 2), round(b, 2)
    val = parse_float_vi(s)
    return (round(val, 2) if val is not None else None), None, None



def parse_int_value(text: Optional[str]) -> Optional[int]:
    value = parse_float_vi(text)
    return int(round(value)) if value is not None else None



def safe_to_datetime(text: Optional[str]) -> Optional[pd.Timestamp]:
    if not text:
        return None
    s = normalize_whitespace(str(text))
    if not s:
        return None
    s = s.replace("/", "-").replace(".", "-")
    fmts = ["%d-%m-%Y", "%Y-%m-%d", "%d-%m-%Y %H:%M", "%Y-%m-%d %H:%M"]
    for fmt in fmts:
        try:
            return pd.Timestamp(datetime.strptime(s, fmt))
        except ValueError:
            continue
    try:
        return pd.to_datetime(s, dayfirst=True, errors="coerce")
    except Exception:
        return None



def infer_city(text: Optional[str], fallback: Optional[str] = None) -> Optional[str]:
    s = normalize_whitespace((text or "").lower()) or ""
    if any(x in s for x in ["hồ chí minh", "ho chi minh", "tp hcm", "tphcm", "sài gòn", "sai gon"]):
        return "TPHCM"
    if any(x in s for x in ["hà nội", "ha noi", "hn"]):
        return "Hà Nội"
    return fallback



def infer_district(text: Optional[str]) -> Optional[str]:
    s = normalize_whitespace((text or "").lower()) or ""
    patterns = [
        r"quận\s+\d+",
        r"quận\s+[a-zà-ỹ\- ]+",
        r"huyện\s+[a-zà-ỹ\- ]+",
        r"thành phố\s+thủ đức",
        r"tp\.?\s*thủ đức",
        r"thủ đức",
        r"nam từ liêm",
        r"bắc từ liêm",
        r"cầu giấy",
        r"thanh xuân",
        r"đống đa",
        r"ba đình",
        r"hoàng mai",
        r"hai bà trưng",
        r"long biên",
        r"hà đông",
        r"tây hồ",
        r"hoàn kiếm",
        r"bình thạnh",
        r"gò vấp",
        r"phú nhuận",
        r"tân bình",
        r"quận 1",
        r"quận 2",
        r"quận 3",
        r"quận 4",
        r"quận 5",
        r"quận 6",
        r"quận 7",
        r"quận 8",
        r"quận 9",
        r"quận 10",
        r"quận 11",
        r"quận 12",
    ]
    for pattern in patterns:
        m = re.search(pattern, s)
        if m:
            return m.group(0).title()
    return None



def canonical_key(record: Dict[str, Any]) -> str:
    title = slugify(str(record.get("title") or ""))
    project = slugify(str(record.get("project_name") or record.get("street") or record.get("district") or ""))
    area = record.get("area_m2")
    price = record.get("price_total_vnd")
    try:
        area_part = str(int(round(float(area)))) if area is not None and not pd.isna(area) else "na"
    except Exception:
        area_part = "na"
    try:
        price_part = str(int(round(float(price) / 10_000_000))) if price is not None and not pd.isna(price) else "na"
    except Exception:
        price_part = "na"
    return f"{title}|{project}|{area_part}|{price_part}"



def standardize_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for col in STANDARD_COLUMNS:
        if col not in out.columns:
            out[col] = None
    ordered = STANDARD_COLUMNS + [c for c in out.columns if c not in STANDARD_COLUMNS]
    return out[ordered]



def write_csv(df: pd.DataFrame, path: Path | str) -> Path:
    path = Path(path)
    ensure_dir(path.parent)
    df.to_csv(path, index=False, encoding="utf-8-sig")
    return path



def read_csv(path: Path | str) -> pd.DataFrame:
    return pd.read_csv(path, encoding="utf-8-sig")



def find_latest_file(directory: Path | str, pattern: str) -> Optional[Path]:
    directory = Path(directory)
    candidates = sorted(directory.glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)
    return candidates[0] if candidates else None



def collect_csv_files(root: Path | str, exclude_dirs: Optional[Sequence[str]] = None) -> List[Path]:
    root = Path(root)
    exclude_dirs = set(exclude_dirs or [])
    files: List[Path] = []
    for path in root.rglob("*.csv"):
        if any(part in exclude_dirs for part in path.parts):
            continue
        files.append(path)
    return sorted(files)



def dump_json(data: Dict[str, Any], path: Path | str) -> Path:
    path = Path(path)
    ensure_dir(path.parent)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    return path



def load_yaml(path: Path | str) -> Dict[str, Any]:
    import yaml
    with Path(path).open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)
